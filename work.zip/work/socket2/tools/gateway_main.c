#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include "../lib/gateway.h"

#define GATEWAY_SERVER_IP    "192.168.211.173"
#define GATEWAY_SERVER_PORT  4444
#define GATEWAY_LISTEN_PORT  4445
#define GATEWAY_PASSPHRASE   "557799"

int main(int argc, char *argv[]) {
    signal(SIGPIPE, SIG_IGN);

    const char *server_ip   = GATEWAY_SERVER_IP;
    int         server_port = GATEWAY_SERVER_PORT;
    int         listen_port = GATEWAY_LISTEN_PORT;
    const char *passphrase  = GATEWAY_PASSPHRASE;

    if (argc >= 2) server_ip   = argv[1];
    if (argc >= 3) server_port = atoi(argv[2]);
    if (argc >= 4) listen_port = atoi(argv[3]);
    if (argc >= 5) passphrase  = argv[4];

    gw_ctx_t ctx;
    if (gw_init(&ctx, server_ip, server_port, listen_port, passphrase) != 0) {
        fprintf(stderr, "gateway init failed\n");
        return 1;
    }

    int rc = gw_run(&ctx);
    gw_cleanup(&ctx);
    return rc;
}
