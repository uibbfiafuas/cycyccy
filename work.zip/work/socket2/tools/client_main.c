#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include "../lib/session.h"

#define HARDCODED_SERVER_IP   "192.168.211.128"
#define HARDCODED_PORT         7778
#define HARDCODED_PASSPHRASE  "557799"

int main(int argc, char *argv[]) {
    signal(SIGPIPE, SIG_IGN);

    const char *ip   = HARDCODED_SERVER_IP;
    int         port = HARDCODED_PORT;
    const char *pass = HARDCODED_PASSPHRASE;

    if (argc >= 2) ip   = argv[1];
    if (argc >= 3) port = atoi(argv[2]);
    if (argc >= 4) pass = argv[3];

    printf("[client] server=%s:%d pass=%s\n", ip, port, pass);
    return client_session_shell(ip, port, pass);
}
