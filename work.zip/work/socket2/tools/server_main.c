#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include "../lib/session.h"

#define HARDCODED_PORT       4444
#define HARDCODED_PASSPHRASE "557799"

int main(int argc, char *argv[]) {
    signal(SIGPIPE, SIG_IGN);

    int         port = HARDCODED_PORT;
    const char *pass = HARDCODED_PASSPHRASE;

    if (argc >= 2) port = atoi(argv[1]);
    if (argc >= 3) pass = argv[2];

    printf("[server] port=%d pass=%s\n", port, pass);
    return server_session_shell(port, pass);
}
