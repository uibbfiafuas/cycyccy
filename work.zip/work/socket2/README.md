# Remo2 — Encrypted Multi-Hop Remote Access Tunnel

## 1. Overview

Remo2 is an encrypted remote access tunnel system designed for educational and security research purposes, providing the following capabilities:

- **Encrypted Remote Shell**: True terminal support via PTY (sudo, vim, top, job control ^Z/fg/bg all work)
- **File Management**: Upload, download, list directory, and delete files over the same encrypted channel
- **Multi-Hop Cascade Topology**: Gateway nodes transparently forward between the controller and leaf nodes, with end-to-end AES-256-GCM encryption (gateway does not decrypt transit data)
- **Fully Static Compilation**: Runtime requires only the Linux kernel, zero dynamic library dependencies

## 2. Network Topology

```
 Server (Node 0)                   C1 Gateway (Node 1)              C2 (Node 2)     C3 (Node 3)
 ┌──────────────────┐        ┌──────────────────────────┐        ┌──────────┐   ┌──────────┐
 │  Interactive      │        │  Local PTY Shell         │        │          │   │          │
 │  Terminal         │        │  File Management         │        │  PTY     │   │  PTY     │
 │                   │        │                          │        │  Shell   │   │  Shell   │
 │  src=0            │◄─TCP──►│  up_fd ──forward──►C2/C3 │◄─TCP──►│ src=2    │◄──┤ src=3    │
 │  dst=1/2/3        │  AES   │  listen_fd ──accept►C2/C3│  AES   │ dst=0    │   │ dst=0    │
 └──────────────────┘        └──────────────────────────┘        └──────────┘   └──────────┘
```

| Node | Role | Binary |
|------|------|--------|
| 0 | Controller | `server` |
| 1 | Gateway (Local Shell + Relay Forwarding) | `gateway` |
| 2, 3 | Leaf Clients (PTY Shell) | `client` |

## 3. Features and Key Code

### 3.1 AES-256-GCM Encryption

All communications are end-to-end encrypted. The gateway (C1) only reads the plaintext `packet_meta_t` header for routing decisions and never decrypts transit data — only the target node decrypts.

Core code: `lib/aes.c`
- `aes_derive_key()` — HKDF-SHA256 key derivation from passphrase (256-bit key)
- `aes_gcm_encrypt()` — Encrypt (AAD=packet_meta plaintext header, preventing metadata tampering)
- `aes_gcm_decrypt()` — Decrypt and verify GCM authentication tag

### 3.2 Two-Layer Protocol Routing

Packet headers use a two-layer routing design (defined in `lib/protocol.h`):

```
Layer 1: stream_id  → 0=SHELL (Shell module), 1=FILE (File module)
Layer 2 (SHELL): task_id → 0=SHELL_OUT (PTY→remote), 1=SHELL_IN (remote→PTY)
Layer 2 (FILE):  file_frame.op → LIST/DOWNLOAD/UPLOAD/DELETE/DATA
```

Node addressing: `src_node` / `dst_node` fields identify 0=Server, 1=Gateway, 2=C2, 3=C3.

### 3.3 PTY True Terminal

Both `client` and `gateway` use `forkpty()` to create a pseudo-terminal, providing full interactive capability: sudo, vim, top, job control (^Z/fg/bg), correct `$TERM` environment variable.

Core code: `lib/session_client.c` (`client_session_shell`), `lib/gateway.c` (`gw_init`)

### 3.4 File Management

Enter the following commands on the Server side:

| Command | Description |
|---------|-------------|
| `!!ls [path]` | List target node directory |
| `!!download <remote_path> [local_path]` | Download file from target node |
| `!!upload <local_path> [remote_path]` | Upload file to target node |
| `!!delete <remote_path>` | Delete file on target node |

Switch target node: `!!c1` / `!!c2` / `!!c3`

Core code: `lib/file_mgr.c` — includes slot management, 64KB bulk disk reads, 158-byte data frame packing, download progress bar.

### 3.5 Gateway Transparent Forwarding

The gateway reads `packet_header_t` (plaintext portion only), determines the destination based on `dst_node`, and forwards the entire header + ciphertext unchanged. Even if the gateway is compromised, it cannot decrypt leaf node communications.

Core code: `lib/gateway.c` (`gw_run`)

### 3.6 Performance Optimizations

- **Dynamic poll timeout**: `poll(0)` at full speed during file transfers, `poll(-1)` zero CPU when idle
- **Batch receive**: Process up to 128 frames per poll wakeup, amortizing syscall overhead
- **64KB large-block I/O**: Single `read()` of 64KB, split into frames in userspace, reducing kernel mode switches
- **Cached /dev/urandom fd**: Avoid fopen/fclose on every encryption, reducing filesystem overhead
- **Idle backoff**: `usleep(1000)` after 20 consecutive empty polls, preventing CPU spin

Typical download speed: ~1.1 MB/s (localhost loopback, including AES-GCM encryption/decryption overhead).

### 3.7 Cascade Suicide Mechanism

When the gateway detects the upstream connection is lost (Server disconnects), it immediately closes all downstream child connections and exits, preventing orphaned half-open connections.

### 3.8 Non-Blocking Shell Input

The client uses a send buffer + dynamic POLLOUT monitoring. When `write()` returns `EAGAIN`, the buffer retains unsent data and the next poll cycle continues sending — preventing the event loop from getting stuck.

## 4. Usage

### 4.1 Static Compilation

```bash
# Run from project root (remo1/)

# Server
gcc -D_POSIX_C_SOURCE=200809L -I./lib -O2 -Wall -std=c11 -static \
    -o tools/server tools/server_main.c \
    lib/session_server.c lib/session.c lib/file_mgr.c lib/tcp_server.c lib/aes.c \
    /usr/lib/x86_64-linux-gnu/libssl.a /usr/lib/x86_64-linux-gnu/libcrypto.a \
    -lpthread -ldl -lutil

# Client
gcc -D_POSIX_C_SOURCE=200809L -I./lib -O2 -Wall -std=c11 -static \
    -o tools/client tools/client_main.c \
    lib/session_client.c lib/session.c lib/file_mgr.c lib/tcp_client.c lib/aes.c \
    /usr/lib/x86_64-linux-gnu/libssl.a /usr/lib/x86_64-linux-gnu/libcrypto.a \
    -lpthread -ldl -lutil

# Gateway
gcc -D_POSIX_C_SOURCE=200809L -I./lib -O2 -Wall -std=c11 -static \
    -o tools/gateway tools/gateway_main.c \
    lib/gateway.c lib/session.c lib/file_mgr.c lib/aes.c \
    lib/tcp_server.c lib/tcp_client.c \
    /usr/lib/x86_64-linux-gnu/libssl.a /usr/lib/x86_64-linux-gnu/libcrypto.a \
    -lpthread -ldl -lutil
```

Output files are in the `tools/` directory.

### 4.2 Hardcoded Defaults

Edit the `#define` macros at the top of `tools/server_main.c`, `tools/client_main.c`, `tools/gateway_main.c` to change default IP, port, and password. Recompile. Hardcoded defaults are used when no command-line arguments are provided.

### 4.3 Single-Hop Deployment (Server ↔ Client)

```
Server (controller):
  ./server 9000 mykey

Client (target):
  ./client <server_ip> 9000 mykey
```

### 4.4 Multi-Hop Cascade Deployment (Server → C1 → C2/C3)

```
Terminal 1 — Server (controller):
  ./server 9000 mykey

Terminal 2 — C1 Gateway:
  ./gateway <server_ip> 9000 9001 mykey

Terminal 3 — C2 (leaf node, another VM):
  ./client <c1_ip> 9001 mykey

Terminal 4 — C3 (leaf node, yet another VM):
  ./client <c1_ip> 9001 mykey
```

On the Server side, use `!!c1` / `!!c2` / `!!c3` to switch target nodes. All shell commands and file operations are routed to the selected target.

### 4.5 Runtime Parameters

| Binary | Arguments | Defaults |
|--------|-----------|----------|
| `server` | `[port] [password]` | port=9000, password="remo2-demo-shared-secret" |
| `client` | `[server_ip] [port] [password]` | 127.0.0.1:9000 |
| `gateway` | `[server_ip] [server_port] [listen_port] [password]` | 127.0.0.1:9000, listen=9001 |

### 4.6 Dependencies

- **Build**: gcc, libssl-dev (provides static .a library files)
- **Runtime**: Linux kernel (static compilation, no dynamic libraries needed)
