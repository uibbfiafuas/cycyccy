#define _GNU_SOURCE
#include "session.h"
#include "aes.h"
#include "protocol.h"
#include "file_mgr.h"
#include "tcp_client.h"

#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <pty.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/wait.h>

#define BATCH_RECV_MAX    128
#define IDLE_BACKOFF_US   1000
#define IDLE_THRESHOLD    20

int client_session_shell(const char *ip, int port, const char *passphrase) {
    const char *pw = session_resolve_passphrase(passphrase);
    uint8_t key[REMO2_AES_KEY_LEN];
    if (aes_derive_key(pw, key) != 0) { fprintf(stderr, "aes_derive_key failed\n"); return 1; }

    int sock = tcp_client_connect(ip, port);
    if (sock < 0) return 1;

    int master_fd;
    pid_t shell_pid = forkpty(&master_fd, NULL, NULL, NULL);
    if (shell_pid < 0) { perror("forkpty"); tcp_client_close(sock); return 1; }

    if (shell_pid == 0) {
        setenv("TERM", "xterm-256color", 1);
        execl("/bin/sh", "sh", "-i", NULL);
        perror("execl"); _exit(127);
    }

    signal(SIGPIPE, SIG_IGN);

    fm_poll_array_t fm_pa; fm_pa_init(&fm_pa);
    fm_ctx_t fm;
    fm_init(&fm, sock, key, 2, 0, session_send_encrypted, &fm_pa);

    fm_poll_array_t *pa = &fm_pa;
    int sock_idx  = fm_pa_add(pa, sock,      POLLIN);
    int pty_idx   = fm_pa_add(pa, master_fd, POLLIN);
    (void)sock_idx; (void)pty_idx;

    uint32_t seq_out = 0;
    char buffer[REMO2_TEXT_LEN];
    int running = 1;

    int idle_count = 0;

    while (running) {

        int has_active = 0;
        for (int si = 0; si < REMO2_FILE_SLOTS; si++) {
            if (fm.slots[si].active &&
                (fm.slots[si].op == REMO2_FILE_OP_DOWNLOAD ||
                 fm.slots[si].op == REMO2_FILE_OP_UPLOAD)) {
                has_active = 1; break;
            }
        }
        int timeout = has_active ? 0 : -1;

        int ret = poll(pa->items, pa->count, timeout);
        if (ret < 0) { if (errno == EINTR) continue; perror("poll"); break; }

        if (ret == 0 && has_active) {
            idle_count++;
            if (idle_count > IDLE_THRESHOLD) {
                usleep(IDLE_BACKOFF_US);
                idle_count = 0;
            }
        } else {
            idle_count = 0;
        }

        if (pa->items[pty_idx].revents & POLLIN) {
            ssize_t n = read(master_fd, buffer, REMO2_TEXT_LEN);
            if (n > 0) {
                session_send_shell(sock, key, &seq_out, REMO2_SHELL_TASK_OUT, 2, 0, buffer, (size_t)n);
            } else { running = 0; break; }
        }

        if (pa->items[sock_idx].revents & POLLIN) {
            for (int batch = 0; batch < BATCH_RECV_MAX; batch++) {
                task_frame_t frame; uint8_t sid;
                int res = session_recv_decrypted(sock, key, &sid, &frame);
                if (res <= 0) { running = 0; break; }

                switch (sid) {
                case REMO2_STREAM_SHELL:
                    if (frame.task_id == REMO2_SHELL_TASK_IN) {
                        size_t len = strnlen(frame.text, REMO2_TEXT_LEN);
                        if (len > 0) {
                            size_t done = 0;
                            while (done < len) {
                                ssize_t w = write(master_fd, frame.text + done, len - done);
                                if (w < 0) { if (errno == EINTR) continue; running = 0; break; }
                                done += (size_t)w;
                            }
                        }
                    }
                    break;
                case REMO2_STREAM_FILE:
                    fm_client_dispatch(&fm, &seq_out, &frame);
                    break;
                }
                if (!running) break;

                struct pollfd check;
                check.fd = sock; check.events = POLLIN;
                if (poll(&check, 1, 0) == 0) break;
            }
        }

        fm_client_flush_downloads(&fm, &seq_out);

        if (pa->items[pty_idx].revents  & (POLLERR | POLLHUP)) running = 0;
        if (pa->items[sock_idx].revents & (POLLERR | POLLHUP)) running = 0;
    }

    close(sock);
    close(master_fd);
    fm_cleanup(&fm);
    kill(shell_pid, SIGTERM);
    waitpid(shell_pid, NULL, 0);
    return 0;
}
