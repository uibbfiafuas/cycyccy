#ifndef REMO2_GATEWAY_H
#define REMO2_GATEWAY_H

#include "protocol.h"
#include <poll.h>
#include <stddef.h>
#include <sys/types.h>

#define GW_MAX_CHILDREN 8

typedef struct {
    int     fd;
    uint8_t node_id;
    int     active;
    int     poll_idx;
    int     write_pending;
    uint8_t tx_buf[8192];
    size_t  tx_len;
} gw_child_t;

typedef struct {

    int          up_fd;

    int          listen_fd;
    int          listen_port;
    gw_child_t   children[GW_MAX_CHILDREN];
    int          child_count;

    int          shell_master_fd;
    pid_t        shell_pid;

    struct pollfd pfds[GW_MAX_CHILDREN + 8];
    int           pfd_count;

    int           up_idx;
    int           listen_idx;
    int           stdin_idx;
    int           shell_idx;

    int           running;
    uint8_t       my_node_id;

    uint8_t       key[32];

} gw_ctx_t;

int  gw_init(gw_ctx_t *ctx, const char *server_ip, int server_port,
             int listen_port, const char *passphrase);
int  gw_run(gw_ctx_t *ctx);
void gw_cleanup(gw_ctx_t *ctx);

#endif
