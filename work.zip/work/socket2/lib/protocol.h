#ifndef REMO2_PROTOCOL_H
#define REMO2_PROTOCOL_H

#include <stdint.h>

#define REMO2_MAGIC          0x52454d32u
#define REMO2_VERSION        1

#define REMO2_TEXT_LEN       160
#define REMO2_FILE_DATA_MAX  140
#define REMO2_FILE_MAX_NAME  128

#define REMO2_DEFAULT_PORT       9000
#define REMO2_DEFAULT_PASSPHRASE "remo2-demo-shared-secret"
#define REMO2_PASSPHRASE_ENV     "REMO2_AES_PASSPHRASE"

#define REMO2_NODE_SERVER   0
#define REMO2_NODE_GATEWAY  1
#define REMO2_NODE_C2       2
#define REMO2_NODE_C3       3
#define REMO2_NODE_MAX      4

#define REMO2_STREAM_SHELL    0
#define REMO2_STREAM_FILE     1
#define REMO2_STREAM_RAW      2

#define REMO2_SHELL_TASK_OUT  0
#define REMO2_SHELL_TASK_IN   1

#define REMO2_FILE_OP_LIST     1
#define REMO2_FILE_OP_DOWNLOAD 2
#define REMO2_FILE_OP_UPLOAD   3
#define REMO2_FILE_OP_DELETE   4
#define REMO2_FILE_OP_DATA     5

#define REMO2_FILE_OK          0x80
#define REMO2_FILE_ERR_OPEN    0x81
#define REMO2_FILE_ERR_IO      0x82

#define REMO2_FILE_SLOTS       4

typedef struct __attribute__((packed)) {
    uint32_t task_id;
    uint32_t seq;
    char text[REMO2_TEXT_LEN];
} task_frame_t;

typedef struct __attribute__((packed)) {
    uint32_t magic;
    uint8_t  version;
    uint8_t  stream_id;
    uint8_t  src_node;
    uint8_t  dst_node;
    uint32_t seq;
    uint32_t payload_len;
} packet_meta_t;

typedef struct __attribute__((packed)) {
    packet_meta_t meta;
    uint8_t iv[12];
    uint8_t tag[16];
} packet_header_t;

typedef struct __attribute__((packed)) {
    uint8_t  op;
    uint8_t  request_id;
    uint16_t reserved;
    uint32_t offset;
    uint32_t data_len;
    uint8_t  data[REMO2_FILE_DATA_MAX];
} file_frame_t;

_Static_assert(sizeof(file_frame_t) <= REMO2_TEXT_LEN,
               "file_frame_t must fit inside task_frame.text");

#endif
