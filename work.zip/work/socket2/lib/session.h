#ifndef REMO2_SESSION_H
#define REMO2_SESSION_H

#include "protocol.h"
#include <stddef.h>
#include <sys/types.h>

typedef struct {
    unsigned char *buf;
    size_t size, head, tail;
} sbuf_t;

void   sbuf_init(sbuf_t *sb);
void   sbuf_free(sbuf_t *sb);
size_t sbuf_len(const sbuf_t *sb);
const unsigned char *sbuf_ptr(const sbuf_t *sb);
int    sbuf_append(sbuf_t *sb, const void *data, size_t len);
void   sbuf_discard(sbuf_t *sb, size_t len);

const char *session_resolve_passphrase(const char *passphrase);
ssize_t     session_read_full(int fd, void *buf, size_t len);
int         session_write_full(int fd, const void *buf, size_t len);

int session_send_encrypted(int sock, const uint8_t *key, uint8_t stream_id,
                           uint8_t src_node, uint8_t dst_node,
                           const task_frame_t *frame);
int session_recv_decrypted(int sock, const uint8_t *key,
                           uint8_t *stream_id, task_frame_t *frame);

void session_send_shell(int sock, const uint8_t *key, uint32_t *seq,
                        uint8_t task_id, uint8_t src_node, uint8_t dst_node,
                        const void *data, size_t len);

int session_parse_cmd(const char *input, int input_len,
                      uint8_t *op, char *path, int path_size);

int client_session_shell(const char *ip, int port, const char *passphrase);
int server_session_shell(int port, const char *passphrase);

#endif
