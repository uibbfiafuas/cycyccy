#include "aes.h"
#include "crypto.h"
#include <string.h>

int aes_derive_key(const char *passphrase, uint8_t key[REMO2_AES_KEY_LEN]) {
    if (!passphrase || !passphrase[0]) return -1;
    const char salt[] = "remo2-static-salt";
    return hkdf_derive((const uint8_t *)salt, strlen(salt),
                       (const uint8_t *)passphrase, strlen(passphrase),
                       key, REMO2_AES_KEY_LEN);
}

int aes_gcm_encrypt(const uint8_t key[REMO2_AES_KEY_LEN],
                    const uint8_t *aad, size_t aad_len,
                    const uint8_t *plaintext, size_t plaintext_len,
                    const uint8_t iv[12],
                    uint8_t *ciphertext,
                    uint8_t tag[16]) {
    crypto_gcm_encrypt(key, aad, aad_len, plaintext, plaintext_len, iv, ciphertext, tag);
    return 0;
}

int aes_gcm_decrypt(const uint8_t key[REMO2_AES_KEY_LEN],
                    const uint8_t *aad, size_t aad_len,
                    const uint8_t *ciphertext, size_t ciphertext_len,
                    const uint8_t iv[12],
                    const uint8_t tag[16],
                    uint8_t *plaintext) {
    return crypto_gcm_decrypt(key, aad, aad_len, ciphertext, ciphertext_len, iv, tag, plaintext);
}
