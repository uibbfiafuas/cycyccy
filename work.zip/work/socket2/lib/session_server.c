#define _GNU_SOURCE
#include "session.h"
#include "aes.h"
#include "protocol.h"
#include "file_mgr.h"
#include "tcp_server.h"

#include <errno.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>

#define BATCH_RECV_MAX   128
#define IDLE_BACKOFF_US  1000
#define IDLE_THRESHOLD   20

int server_session_shell(int port, const char *passphrase) {
    const char *pw = session_resolve_passphrase(passphrase);
    uint8_t key[REMO2_AES_KEY_LEN];
    if (aes_derive_key(pw, key) != 0) { fprintf(stderr, "aes_derive_key failed\n"); return 1; }

    int listen_fd = tcp_server_listen(port);
    if (listen_fd < 0) return 1;
    printf("[server] listening on port %d ...\n", port);
    int cli_fd = tcp_server_accept(listen_fd);
    tcp_server_close(listen_fd);
    if (cli_fd < 0) return 1;
    printf("[server] client connected.\n");
    printf("[server] !!c1/!!c2/!!c3 to switch | !!ls/dl/up/del for files\n\n");

    uint8_t target_node = REMO2_NODE_GATEWAY;
    uint8_t src_node    = REMO2_NODE_SERVER;

    fm_ctx_t fm;
    fm_init(&fm, cli_fd, key, src_node, target_node, session_send_encrypted, NULL);

    struct pollfd pfds[2];
    pfds[0].fd     = cli_fd;       pfds[0].events = POLLIN;
    pfds[1].fd     = STDIN_FILENO;  pfds[1].events = POLLIN;

    uint32_t seq_in  = 0;
    char line_buf[REMO2_TEXT_LEN];
    int  line_len = 0;
    int  running  = 1;
    int  idle_count = 0;

    while (running) {

        int has_active = 0;
        for (int si = 0; si < REMO2_FILE_SLOTS; si++) {
            if (fm.slots[si].active &&
                (fm.slots[si].op == REMO2_FILE_OP_UPLOAD ||
                 fm.slots[si].op == REMO2_FILE_OP_DOWNLOAD)) {
                has_active = 1; break;
            }
        }
        int timeout = has_active ? 0 : -1;

        int ret = poll(pfds, 2, timeout);
        if (ret < 0) { if (errno == EINTR) continue; perror("poll"); break; }

        if (ret == 0 && has_active) {
            idle_count++;
            if (idle_count > IDLE_THRESHOLD) { usleep(IDLE_BACKOFF_US); idle_count = 0; }
        } else {
            idle_count = 0;
        }

        if (pfds[0].revents & POLLIN) {
            for (int batch = 0; batch < BATCH_RECV_MAX; batch++) {
                task_frame_t frame; uint8_t sid;
                int res = session_recv_decrypted(cli_fd, key, &sid, &frame);
                if (res <= 0) {
                    char peek[256];
                    ssize_t pn = recv(cli_fd, peek, sizeof(peek) - 1, MSG_PEEK | MSG_DONTWAIT);
                    if (pn > 0) {
                        peek[pn] = '\0';
                        printf("\n[server] peer sent (%zd bytes): ", pn);
                        for (ssize_t i = 0; i < pn && i < 120; i++)
                            printf("%c", (peek[i] >= 32 && peek[i] < 127) ? peek[i] : '.');
                    }
                    printf("\n[server] connection closed (res=%d).\n", res);
                    running = 0; break; }

                switch (sid) {
                case REMO2_STREAM_SHELL:
                    if (frame.task_id == REMO2_SHELL_TASK_OUT) {
                        fwrite(frame.text, 1, strnlen(frame.text, REMO2_TEXT_LEN), stdout);
                        fflush(stdout);
                    }
                    break;
                case REMO2_STREAM_FILE:
                    fm_server_dispatch(&fm, &frame);
                    break;
                }
                if (!running) break;

                struct pollfd chk; chk.fd = cli_fd; chk.events = POLLIN;
                if (poll(&chk, 1, 0) == 0) break;
            }
        }

        if (pfds[1].revents & POLLIN) {
            char raw[REMO2_TEXT_LEN];
            ssize_t n = read(STDIN_FILENO, raw, sizeof(raw) - 1);
            if (n <= 0) { pfds[1].fd = -1; /* stdin closed, keep running */ }
            else for (ssize_t i = 0; i < n; i++) {
                line_buf[line_len++] = raw[i];
                if (raw[i] == '\n' || line_len >= (int)sizeof(line_buf) - 1) {
                    line_buf[line_len] = '\0';
                    int llen = line_len;
                    line_len = 0;

                    uint8_t op;
                    char path_buf[REMO2_FILE_MAX_NAME];

                    if (llen >= 4 && memcmp(line_buf, "!!c2", 4) == 0 &&
                        (llen == 4 || line_buf[4] == '\n' || line_buf[4] == '\r' || line_buf[4] == ' ')) {
                        target_node = 2;
                        fm.src_node = src_node; fm.dst_node = target_node;
                        printf("[server] target -> C2\n");
                        if (line_buf[4] == ' ') {
                            const char *rest = line_buf + 5;
                            int rlen = llen - 5;
                            if (rlen > 0 && rest[rlen-1] == '\n' && rest[0] != '\n')
                                session_send_shell(cli_fd, key, &seq_in, REMO2_SHELL_TASK_IN,
                                                   src_node, target_node, rest, (size_t)rlen);
                        }
                    } else if (llen >= 4 && memcmp(line_buf, "!!c3", 4) == 0 &&
                               (llen == 4 || line_buf[4] == '\n' || line_buf[4] == '\r' || line_buf[4] == ' ')) {
                        target_node = 3;
                        fm.src_node = src_node; fm.dst_node = target_node;
                        printf("[server] target -> C3\n");
                        if (line_buf[4] == ' ') {
                            const char *rest = line_buf + 5;
                            int rlen = llen - 5;
                            if (rlen > 0 && rest[rlen-1] == '\n' && rest[0] != '\n')
                                session_send_shell(cli_fd, key, &seq_in, REMO2_SHELL_TASK_IN,
                                                   src_node, target_node, rest, (size_t)rlen);
                        }
                    } else if (llen >= 4 && memcmp(line_buf, "!!c1", 4) == 0 &&
                               (llen == 4 || line_buf[4] == '\n' || line_buf[4] == '\r')) {
                        target_node = 1;
                        fm.src_node = src_node; fm.dst_node = target_node;
                        printf("[server] target -> C1\n");
                    } else if (session_parse_cmd(line_buf, llen, &op, path_buf, sizeof(path_buf))) {
                        const char *psrc = path_buf;
                        const char *pdst = psrc + strlen(psrc) + 1;
                        if ((size_t)(pdst - path_buf) >= sizeof(path_buf)) pdst = "";
                        char expanded_dst[REMO2_FILE_MAX_NAME] = "";
                        const char *home = getenv("HOME");
                        if (pdst[0] == '~' && home && (pdst[1] == '/' || pdst[1] == '\0')) {
                            snprintf(expanded_dst, sizeof(expanded_dst), "%s%s", home, pdst + 1);
                            pdst = expanded_dst;
                        }
                        fm_server_prepare_cmd(&fm, &seq_in, op, psrc, pdst);
                    } else {
                        session_send_shell(cli_fd, key, &seq_in, REMO2_SHELL_TASK_IN,
                                           src_node, target_node, line_buf, (size_t)llen);
                    }
                    if (raw[i] != '\n') break;
                }
            }
        }

        fm_server_flush_uploads(&fm, &seq_in);
    }

    tcp_server_close(cli_fd);
    fm_cleanup(&fm);
    return 0;
}
