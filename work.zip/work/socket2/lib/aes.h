#ifndef REMO2_AES_H
#define REMO2_AES_H

#include <stddef.h>
#include <stdint.h>

#define REMO2_AES_KEY_LEN 32

int aes_derive_key(const char *passphrase, uint8_t key[REMO2_AES_KEY_LEN]);

int aes_gcm_encrypt(const uint8_t key[REMO2_AES_KEY_LEN],
                    const uint8_t *aad, size_t aad_len,
                    const uint8_t *plaintext, size_t plaintext_len,
                    const uint8_t iv[12],
                    uint8_t *ciphertext,
                    uint8_t tag[16]);

int aes_gcm_decrypt(const uint8_t key[REMO2_AES_KEY_LEN],
                    const uint8_t *aad, size_t aad_len,
                    const uint8_t *ciphertext, size_t ciphertext_len,
                    const uint8_t iv[12],
                    const uint8_t tag[16],
                    uint8_t *plaintext);

#endif
