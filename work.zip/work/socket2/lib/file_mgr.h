#ifndef REMO2_FILE_MGR_H
#define REMO2_FILE_MGR_H

#include "protocol.h"
#include <poll.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/types.h>

#define FM_MAX_POLL_FDS 64

typedef struct {
    struct pollfd items[FM_MAX_POLL_FDS];
    int count;
} fm_poll_array_t;

void fm_pa_init(fm_poll_array_t *pa);
int  fm_pa_add(fm_poll_array_t *pa, int fd, short events);
void fm_pa_remove(fm_poll_array_t *pa, int idx);
int  fm_pa_find(fm_poll_array_t *pa, int fd);

typedef struct {
    int      active;
    uint8_t  request_id;
    uint8_t  op;
    pid_t    child_pid;
    int      pipe_fd;
    int      poll_idx;
    FILE    *fp;
    uint32_t offset;
    uint32_t total_size;
    int      last_pct;
    char     path[REMO2_FILE_MAX_NAME];
} fm_slot_t;

typedef int (*fm_send_fn)(int sock, const uint8_t *key, uint8_t stream_id,
                          uint8_t src_node, uint8_t dst_node,
                          const task_frame_t *frame);

typedef struct {
    int              sock;
    const uint8_t   *key;
    uint8_t          src_node;
    uint8_t          dst_node;
    fm_send_fn       send_fn;
    fm_poll_array_t *pa;
    fm_slot_t        slots[REMO2_FILE_SLOTS];
} fm_ctx_t;

void fm_init(fm_ctx_t *ctx, int sock, const uint8_t *key, uint8_t src_node,
             uint8_t dst_node, fm_send_fn send_fn, fm_poll_array_t *pa);

int  fm_allocate_slot(fm_ctx_t *ctx);
int  fm_find_slot(fm_ctx_t *ctx, uint8_t rid);
void fm_free_slot(fm_ctx_t *ctx, int idx);

void fm_parse_frame(const task_frame_t *frame, file_frame_t *ff);
void fm_build_cmd_frame(task_frame_t *frame, uint8_t op, uint8_t rid,
                         const char *data, size_t data_len);
void fm_build_data_frame(task_frame_t *frame, uint8_t rid,
                          uint32_t offset, const uint8_t *data, uint32_t len);
void fm_build_status_frame(task_frame_t *frame, uint8_t status, uint8_t rid, uint32_t info);

void fm_send_frame(fm_ctx_t *ctx, uint32_t *seq, const task_frame_t *frame);

void fm_client_dispatch(fm_ctx_t *ctx, uint32_t *seq, const task_frame_t *frame);

void fm_client_flush_downloads(fm_ctx_t *ctx, uint32_t *seq);

int  fm_server_prepare_cmd(fm_ctx_t *ctx, uint32_t *seq,
                            uint8_t op, const char *psrc, const char *pdst);

void fm_server_flush_uploads(fm_ctx_t *ctx, uint32_t *seq);

void fm_server_dispatch(fm_ctx_t *ctx, const task_frame_t *frame);

void fm_cleanup(fm_ctx_t *ctx);

uint8_t fm_next_rid(void);

#endif
