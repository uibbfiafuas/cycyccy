#ifndef CRYPTO_H
#define CRYPTO_H
#include <stddef.h>
#include <stdint.h>

#define CRYPTO_KEYLEN  32
#define CRYPTO_IVLEN   12
#define CRYPTO_TAGLEN  16

void crypto_gcm_encrypt(const uint8_t key[32],
                     const uint8_t *aad, size_t aad_len,
                     const uint8_t *plaintext, size_t plaintext_len,
                     const uint8_t iv[12],
                     uint8_t *ciphertext, uint8_t tag[16]);

int crypto_gcm_decrypt(const uint8_t key[32],
                    const uint8_t *aad, size_t aad_len,
                    const uint8_t *ciphertext, size_t ciphertext_len,
                    const uint8_t iv[12],
                    const uint8_t tag[16], uint8_t *plaintext);

int hkdf_derive(const uint8_t *salt, size_t salt_len,
                const uint8_t *ikm, size_t ikm_len,
                uint8_t *out, size_t out_len);

#endif
