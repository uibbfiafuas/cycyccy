#ifndef TCP_SERVER_H
#define TCP_SERVER_H

int tcp_server_listen(int port);
int tcp_server_accept(int listen_fd);
void tcp_server_close(int fd);

#endif
