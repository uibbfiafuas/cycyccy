#define _GNU_SOURCE
#include "session.h"
#include "aes.h"
#include "protocol.h"
#include "file_mgr.h"

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>

const char *session_resolve_passphrase(const char *passphrase) {
    if (passphrase && passphrase[0]) return passphrase;
    const char *env = getenv(REMO2_PASSPHRASE_ENV);
    return env ? env : REMO2_DEFAULT_PASSPHRASE;
}

ssize_t session_read_full(int fd, void *buf, size_t len) {
    size_t done = 0;
    unsigned char *p = (unsigned char *)buf;
    while (done < len) {
        ssize_t r = read(fd, p + done, len - done);
        if (r < 0) { if (errno == EINTR) continue; return -1; }
        if (r == 0) return 0;
        done += (size_t)r;
    }
    return (ssize_t)done;
}

int session_write_full(int fd, const void *buf, size_t len) {
    size_t done = 0;
    const unsigned char *p = (const unsigned char *)buf;
    while (done < len) {
        ssize_t w = write(fd, p + done, len - done);
        if (w < 0) { if (errno == EINTR) continue; return -1; }
        done += (size_t)w;
    }
    return 0;
}

static void random_iv(uint8_t iv[12]) {
    static int ufd = -1;
    if (ufd < 0) ufd = open("/dev/urandom", O_RDONLY | O_CLOEXEC);
    if (ufd >= 0) { session_read_full(ufd, iv, 12); return; }
    for (int i = 0; i < 12; i++) iv[i] = (uint8_t)(rand() % 256);
}

int session_send_encrypted(int sock, const uint8_t *key, uint8_t stream_id,
                           uint8_t src_node, uint8_t dst_node,
                           const task_frame_t *frame) {
    packet_header_t header;
    uint8_t ciphertext[sizeof(task_frame_t)];
    memset(&header, 0, sizeof(header));
    header.meta.magic       = htonl(REMO2_MAGIC);
    header.meta.version     = REMO2_VERSION;
    header.meta.stream_id   = stream_id;
    header.meta.src_node    = src_node;
    header.meta.dst_node    = dst_node;
    header.meta.seq         = htonl(frame->seq);
    header.meta.payload_len = htonl((uint32_t)sizeof(*frame));
    random_iv(header.iv);

    if (aes_gcm_encrypt(key,
                        (const uint8_t *)&header.meta, sizeof(header.meta),
                        (const uint8_t *)frame, sizeof(*frame),
                        header.iv, ciphertext, header.tag) != 0) {
        fprintf(stderr, "aes_gcm_encrypt failed\n");
        return -1;
    }
    if (session_write_full(sock, &header, sizeof(header)) < 0) return -1;
    if (session_write_full(sock, ciphertext, sizeof(ciphertext)) < 0) return -1;
    return 0;
}

int session_recv_decrypted(int sock, const uint8_t *key,
                           uint8_t *stream_id, task_frame_t *frame) {
    packet_header_t header;
    ssize_t r = session_read_full(sock, &header, sizeof(header));
    if (r == 0) return 0;
    if (r < 0) { perror("read header"); return -1; }
    if (ntohl(header.meta.magic) != REMO2_MAGIC || header.meta.version != REMO2_VERSION) {
        fprintf(stderr, "invalid packet header\n"); return -1;
    }
    uint32_t payload_len = ntohl(header.meta.payload_len);
    if (payload_len != sizeof(task_frame_t)) {
        fprintf(stderr, "unexpected payload length: %u\n", payload_len); return -1;
    }
    uint8_t ciphertext[sizeof(task_frame_t)];
    r = session_read_full(sock, ciphertext, sizeof(ciphertext));
    if (r == 0) return 0;
    if (r < 0) { perror("read ciphertext"); return -1; }
    memset(frame, 0, sizeof(*frame));
    if (aes_gcm_decrypt(key,
                        (const uint8_t *)&header.meta, sizeof(header.meta),
                        ciphertext, sizeof(ciphertext),
                        header.iv, header.tag,
                        (uint8_t *)frame) != 0) {
        fprintf(stderr, "aes_gcm_decrypt failed (tag mismatch)\n");
        return -1;
    }
    *stream_id = header.meta.stream_id;
    return 1;
}

void sbuf_init(sbuf_t *sb) { memset(sb, 0, sizeof(*sb)); }
void sbuf_free(sbuf_t *sb) { free(sb->buf); sbuf_init(sb); }
size_t sbuf_len(const sbuf_t *sb) { return sb->tail - sb->head; }
const unsigned char *sbuf_ptr(const sbuf_t *sb) { return sb->buf + sb->head; }

int sbuf_append(sbuf_t *sb, const void *data, size_t len) {
    if (sb->tail + len > sb->size) {
        size_t new_size = sb->size ? sb->size * 2 : 4096;
        while (new_size < sb->tail + len) new_size *= 2;
        unsigned char *new_buf = realloc(sb->buf, new_size);
        if (!new_buf) return -1;
        sb->buf  = new_buf;
        sb->size = new_size;
    }
    memcpy(sb->buf + sb->tail, data, len);
    sb->tail += len;
    return 0;
}

void sbuf_discard(sbuf_t *sb, size_t len) {
    sb->head += len;
    if (sb->head == sb->tail) sb->head = sb->tail = 0;
}

void session_send_shell(int sock, const uint8_t *key, uint32_t *seq,
                        uint8_t task_id, uint8_t src_node, uint8_t dst_node,
                        const void *data, size_t len) {
    task_frame_t frame;
    memset(&frame, 0, sizeof(frame));
    frame.task_id = task_id;
    frame.seq     = (*seq)++;
    if (len > REMO2_TEXT_LEN) len = REMO2_TEXT_LEN;
    memcpy(frame.text, data, len);
    session_send_encrypted(sock, key, REMO2_STREAM_SHELL, src_node, dst_node, &frame);
}

int session_parse_cmd(const char *input, int input_len,
                      uint8_t *op, char *path, int path_size) {
    if (input_len < 3 || memcmp(input, "!!", 2) != 0) return 0;
    const char *cs = input + 2;
    int cl = input_len - 2;

    #define EXTRACT(start, rem, buf, sz) do { \
        const char *_p = (start); int _r = (rem); \
        const char *_sp = memchr(_p, ' ', _r); \
        int _l = _sp ? (int)(_sp - _p) : _r; \
        if (_l > (sz)-1) _l = (sz)-1; \
        memcpy((buf), _p, _l); (buf)[_l] = '\0'; \
        while ((buf)[0] && ((buf)[strlen(buf)-1]=='\n' || (buf)[strlen(buf)-1]=='\r')) \
            (buf)[strlen(buf)-1] = '\0'; \
        (start) = _sp ? _sp + 1 : _p + _r; \
        (rem)   = _sp ? _r - _l - 1 : 0; \
    } while(0)

    if (cl > 8 && memcmp(cs, "download ", 9) == 0) {
        *op = REMO2_FILE_OP_DOWNLOAD;
        const char *p = cs + 9; int r = cl - 9;
        char src[REMO2_FILE_MAX_NAME], dst[REMO2_FILE_MAX_NAME] = "";
        EXTRACT(p, r, src, sizeof(src));
        if (r > 0) EXTRACT(p, r, dst, sizeof(dst));
        int sl = (int)strlen(src); memcpy(path, src, sl + 1);
        if (dst[0]) memcpy(path + sl + 1, dst, strlen(dst) + 1);
        else path[sl + 1] = '\0';
        return 1;
    }
    if (cl > 6 && memcmp(cs, "upload ", 7) == 0) {
        *op = REMO2_FILE_OP_UPLOAD;
        const char *p = cs + 7; int r = cl - 7;
        char src[REMO2_FILE_MAX_NAME], dst[REMO2_FILE_MAX_NAME] = "";
        EXTRACT(p, r, src, sizeof(src));
        if (r > 0) EXTRACT(p, r, dst, sizeof(dst));
        int sl = (int)strlen(src); memcpy(path, src, sl + 1);
        if (dst[0]) memcpy(path + sl + 1, dst, strlen(dst) + 1);
        else path[sl + 1] = '\0';
        return 1;
    }
    #undef EXTRACT

    if (cl > 4 && memcmp(cs, "list ", 5) == 0) {
        *op = REMO2_FILE_OP_LIST;
        int pl = cl - 5;
        memcpy(path, cs + 5, pl < path_size - 1 ? (size_t)pl : (size_t)(path_size - 1));
        path[pl < path_size - 1 ? pl : path_size - 1] = '\0';
        while (path[0] && (path[strlen(path)-1]=='\n' || path[strlen(path)-1]=='\r'))
            path[strlen(path)-1] = '\0';
        return 1;
    }
    if (cl >= 4 && memcmp(cs, "list", 4) == 0 && (cl == 4 || cs[4]=='\n' || cs[4]=='\r')) {
        *op = REMO2_FILE_OP_LIST; path[0]='.'; path[1]='\0'; return 1;
    }
    if (cl >= 2 && memcmp(cs, "ls", 2) == 0 && (cl == 2 || cs[2]=='\n' || cs[2]=='\r' || cs[2]==' ')) {
        *op = REMO2_FILE_OP_LIST;
        int pl = (cl > 2 && cs[2]==' ') ? cl - 3 : 0;
        if (pl > 0) {
            memcpy(path, cs+3, pl < path_size-1 ? (size_t)pl : (size_t)(path_size-1));
            path[pl < path_size-1 ? pl : path_size-1] = '\0';
            while (path[0] && (path[strlen(path)-1]=='\n' || path[strlen(path)-1]=='\r'))
                path[strlen(path)-1] = '\0';
        } else { path[0]='.'; path[1]='\0'; }
        return 1;
    }
    if (cl > 6 && memcmp(cs, "delete ", 7) == 0) {
        *op = REMO2_FILE_OP_DELETE;
        int pl = cl - 7;
        memcpy(path, cs+7, pl < path_size-1 ? (size_t)pl : (size_t)(path_size-1));
        path[pl < path_size-1 ? pl : path_size-1] = '\0';
        while (path[0] && (path[strlen(path)-1]=='\n' || path[strlen(path)-1]=='\r'))
            path[strlen(path)-1] = '\0';
        return 1;
    }
    return 0;
}
