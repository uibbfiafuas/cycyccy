#ifndef TCP_CLIENT_H
#define TCP_CLIENT_H

int tcp_client_connect(const char *ip, int port);
void tcp_client_close(int fd);

#endif
