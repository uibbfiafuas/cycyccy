#include <Uefi.h>
#include <Library/UefiLib.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/DevicePathLib.h>
#include <Protocol/SimpleFileSystem.h>
#include <Protocol/LoadedImage.h>
#include <Protocol/DevicePath.h>
#include "ElfData.h"

STATIC
VOID
WaitForKey (
  VOID
  )
{
  EFI_INPUT_KEY  Key;
  UINTN          Index;

  Print (L"\nPress any key to continue...\n");
  gBS->WaitForEvent (1, &gST->ConIn->WaitForKey, &Index);
  gST->ConIn->ReadKeyStroke (gST->ConIn, &Key);
}

STATIC
VOID
ConnectAllControllers (
  VOID
  )
{
  EFI_STATUS  Status;
  EFI_HANDLE  *Handles;
  UINTN       HandleCount;
  UINTN       Index;

  Handles     = NULL;
  HandleCount = 0;
  Status = gBS->LocateHandleBuffer (AllHandles, NULL, NULL, &HandleCount, &Handles);
  if (EFI_ERROR (Status)) {
    return;
  }

  for (Index = 0; Index < HandleCount; Index++) {
    gBS->ConnectController (Handles[Index], NULL, NULL, TRUE);
  }

  gBS->FreePool (Handles);
}

STATIC
EFI_STATUS
LocateFileSystem (
  OUT EFI_SIMPLE_FILE_SYSTEM_PROTOCOL  **FileSystem
  )
{
  EFI_STATUS                 Status;
  EFI_LOADED_IMAGE_PROTOCOL  *LoadedImage;
  EFI_DEVICE_PATH_PROTOCOL   *FullPath;
  EFI_DEVICE_PATH_PROTOCOL   *Remaining;
  EFI_HANDLE                 Handle;

  Status = gBS->HandleProtocol (
                  gImageHandle,
                  &gEfiLoadedImageProtocolGuid,
                  (VOID **)&LoadedImage
                  );
  if (EFI_ERROR (Status)) {
    return Status;
  }

  // Fast path: the device we were loaded from usually already exposes SimpleFileSystem.
  Status = gBS->HandleProtocol (
                  LoadedImage->DeviceHandle,
                  &gEfiSimpleFileSystemProtocolGuid,
                  (VOID **)FileSystem
                  );
  if (!EFI_ERROR (Status)) {
    return EFI_SUCCESS;
  }

  // Rebuild the full device path and locate the exact device hosting this image,
  // so we never write to an unrelated FAT partition.
  FullPath = AppendDevicePath (
               DevicePathFromHandle (LoadedImage->DeviceHandle),
               LoadedImage->FilePath
               );
  if (FullPath == NULL) {
    return EFI_OUT_OF_RESOURCES;
  }

  Remaining = FullPath;
  Handle    = NULL;
  Status = gBS->LocateDevicePath (&gEfiSimpleFileSystemProtocolGuid, &Remaining, &Handle);
  FreePool (FullPath);
  if (EFI_ERROR (Status)) {
    return Status;
  }

  return gBS->HandleProtocol (Handle, &gEfiSimpleFileSystemProtocolGuid, (VOID **)FileSystem);
}

STATIC
EFI_STATUS
BootOsLoader (
  VOID
  )
{
  EFI_STATUS                 Status;
  EFI_LOADED_IMAGE_PROTOCOL  *LoadedImage;
  EFI_DEVICE_PATH_PROTOCOL   *FilePath;
  EFI_HANDLE                 OsImageHandle;

  Status = gBS->HandleProtocol (gImageHandle, &gEfiLoadedImageProtocolGuid, (VOID **)&LoadedImage);
  if (EFI_ERROR (Status)) {
    return Status;
  }

  // Chain-load GRUB directly. Secure Boot is off, so grubx64.efi runs standalone.
  // (Switch to shimx64.efi if you need to go through shim.)
  FilePath = FileDevicePath (LoadedImage->DeviceHandle, L"\\EFI\\ubuntu\\grubx64.efi");
  if (FilePath == NULL) {
    return EFI_OUT_OF_RESOURCES;
  }

  OsImageHandle = NULL;
  Status = gBS->LoadImage (TRUE, gImageHandle, FilePath, NULL, 0, &OsImageHandle);
  FreePool (FilePath);
  if (EFI_ERROR (Status)) {
    return Status;
  }

  Print (L"Chain-loading \\EFI\\ubuntu\\grubx64.efi ...\n");
  return gBS->StartImage (OsImageHandle, NULL, NULL);
}

EFI_STATUS
EFIAPI
UefiMain (
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  EFI_STATUS                       Status;
  EFI_SIMPLE_FILE_SYSTEM_PROTOCOL  *FileSystem;
  EFI_FILE_PROTOCOL                *Root;
  EFI_FILE_PROTOCOL                *Dir;
  EFI_FILE_PROTOCOL                *File;
  UINTN                            BufferSize;
  UINTN                            RetryCount;

  Print (L"\n=== MyElfLoader: dropping embedded ELF ===\n");
  Print (L"Embedded payload: %lu bytes (0x%lx)\n",
         (UINT64)loader_len, (UINT64)loader_len);

  // --- 连接所有控制器，确保磁盘/文件系统驱动就绪 ---
  Print (L"Connecting all controllers...\n");
  ConnectAllControllers ();

  // --- 重试查找文件系统（最多 5 次） ---
  FileSystem = NULL;
  for (RetryCount = 0; RetryCount < 5; RetryCount++) {
    if (RetryCount > 0) {
      Print (L"Retry %d/5: waiting 1 second...\n", RetryCount);
      gBS->Stall (1000000); // 1 秒
    }
    Status = LocateFileSystem (&FileSystem);
    if (!EFI_ERROR (Status)) {
      Print (L"Filesystem found on attempt %d.\n", RetryCount + 1);
      break;
    }
  }

  if (EFI_ERROR (Status)) {
    Print (L"ERROR: no filesystem found after 5 retries: %r\n", Status);
    WaitForKey ();
    return Status;
  }

  Root = NULL;
  Status = FileSystem->OpenVolume (FileSystem, &Root);
  if (EFI_ERROR (Status)) {
    Print (L"ERROR: OpenVolume failed: %r\n", Status);
    WaitForKey ();
    return Status;
  }

  // Open (or create) the \EFI directory.
  Dir = NULL;
  Status = Root->Open (Root, &Dir, L"EFI", EFI_FILE_MODE_READ, 0);
  if (EFI_ERROR (Status)) {
    Status = Root->Open (
                     Root,
                     &Dir,
                     L"EFI",
                     EFI_FILE_MODE_READ | EFI_FILE_MODE_WRITE | EFI_FILE_MODE_CREATE,
                     EFI_FILE_DIRECTORY
                     );
    if (EFI_ERROR (Status)) {
      Print (L"ERROR: cannot open/create \\EFI: %r\n", Status);
      Root->Close (Root);
      WaitForKey ();
      return Status;
    }
  }

  // Remove any stale copy first. Delete() takes only the handle and closes it.
  File = NULL;
  Status = Dir->Open (Dir, &File, L"loader", EFI_FILE_MODE_READ | EFI_FILE_MODE_WRITE, 0);
  if (!EFI_ERROR (Status)) {
    File->Delete (File);
  }

  File = NULL;
  Status = Dir->Open (
                   Dir,
                   &File,
                   L"loader",
                   EFI_FILE_MODE_READ | EFI_FILE_MODE_WRITE | EFI_FILE_MODE_CREATE,
                   0
                   );
  if (EFI_ERROR (Status)) {
    Print (L"ERROR: cannot create \\EFI\\loader: %r\n", Status);
    Dir->Close (Dir);
    Root->Close (Root);
    WaitForKey ();
    return Status;
  }

  BufferSize = (UINTN)loader_len;
  Status = File->Write (File, &BufferSize, (VOID *)loader);
  if (EFI_ERROR (Status) || BufferSize != (UINTN)loader_len) {
    Print (L"ERROR: write failed: %r (wrote %lu of %lu bytes)\n",
           Status, (UINT64)BufferSize, (UINT64)loader_len);
    File->Close (File);
    Dir->Close (Dir);
    Root->Close (Root);
    WaitForKey ();
    return EFI_DEVICE_ERROR;
  }

  File->Flush (File);
  File->Close (File);
  Dir->Close (Dir);
  Root->Close (Root);

  Print (L"SUCCESS: wrote %lu bytes to \\EFI\\loader\n", (UINT64)loader_len);

  // Chain-load the OS loader so the system continues booting normally.
  Status = BootOsLoader ();
  Print (L"ERROR: OS loader failed to start: %r\n", Status);
  WaitForKey ();
  return Status;
}