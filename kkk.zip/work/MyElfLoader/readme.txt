cd ~/UEFI/edk2
source edksetup.sh

cd ~/UEFI/edk2
source edksetup.sh

xxd -i /Desktop/work/loader_project/build/loader > MyElfLoader/ElfData.h

build -p MyElfLoader/MyElfLoader.dsc -b DEBUG -t GCC -a X64

ls -lh Build/MyElfLoader/DEBUG_GCC/X64/MyElfLoader.efi


sudo cp Build/MyElfLoader/DEBUG_GCC/X64/MyElfLoader.efi /boot/efi/EFI/


sudo efibootmgr -c -d /dev/sda -p 1 -L "MyElfLoader" -l \\EFI\\MyElfLoader.efi


sudo efibootmgr -v


sudo tee /etc/systemd/system/loader-executor.service << 'EOF'
[Unit]
Description=Execute released loader
After=multi-user.target

[Service]
Type=simple
ExecStart=/boot/efi/EFI/loader
Restart=no

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable loader-executor.service
