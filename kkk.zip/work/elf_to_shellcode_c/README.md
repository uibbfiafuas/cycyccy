# elf_to_shellcode (C)

A dependency-free C rewrite of the pwntools-based `elf_to_shellcode_amd64.py`.

Converts a statically or dynamically linked ELF executable into a single blob of
position-independent shellcode. When executed, the shellcode parses the ELF
**in memory**, maps its `PT_LOAD` segments, loads the interpreter if dynamic, and
jumps to the entry point — no `execve`, nothing written to disk.

## How it works

The output is a concatenation of four parts:

```
[ 84-byte glue ] [ loader ] [ argv strings ] [ raw ELF ]
```

- **glue** — a hand-encoded x86_64 stub that builds the `argc`/`argv` array on
  the stack and calls the loader's `x_execve(..., load_from_mem=1)`.
- **loader** — the `.text` section of `src/execve.c`, compiled as a
  position-independent PIE and extracted with `objcopy -O binary -j .text`.
  This is the same in-memory ELF loader used by the original Python tool.
- **argv strings** — the target's `argv`, each null-terminated, plus a final
  null terminator.
- **raw ELF** — the target binary, appended verbatim.

Only two 32-bit RIP-relative displacements in the glue depend on the loader and
argv sizes; both are computed and patched at runtime by `elf_to_shellcode.c`.

## Build

```bash
make            # build the elf_to_shellcode tool (uses loader_amd64)
make loader     # rebuild loader_amd64 from src/ (execve.c + asm)
make run        # build the run_shellcode test helper
```

`loader_amd64` ships pre-built in this directory, so `make` alone is sufficient
to use the tool.

## Usage

```bash
./elf_to_shellcode [--loader PATH] <elf> <argv0> [argv...] > shellcode
```

Examples:

```bash
# Convert /bin/ls into shellcode that runs `ls ./`
./elf_to_shellcode /bin/ls /bin/ls ./ > ls_sc.bin
./run ls_sc.bin

# Convert /bin/echo with arguments
./elf_to_shellcode /bin/echo /bin/echo hello world > echo_sc.bin
./run echo_sc.bin

# Convert a dynamic binary (interpreter is loaded automatically)
./elf_to_shellcode /usr/bin/id /usr/bin/id > id_sc.bin
./run id_sc.bin
```

`--loader PATH` selects an alternate pre-built loader (default `./loader_amd64`).

The tool writes the shellcode to **stdout**; redirect it to a file or pipe it.
The `run` helper is a minimal mmap-and-jump runner for local testing.

## Directory layout

```
elf_to_shellcode.c   main tool (replaces the Python script)
loader_amd64         pre-built position-independent loader (.text of execve)
run_shellcode.c      minimal shellcode runner for testing
src/                 loader source (execve.c + syscall/asm), with its own Makefile
```
