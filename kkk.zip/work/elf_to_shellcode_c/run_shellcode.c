#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <unistd.h>

/* Minimal shellcode runner for testing: mmap the file RWX, jump into it. */

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage : %s <shellcode>\n", argv[0]);
        exit(1);
    }

    FILE *fp = fopen(argv[1], "rb");
    if (!fp) {
        perror("fopen");
        return -1;
    }

    fseek(fp, 0, SEEK_END);
    long len = ftell(fp);
    if (len <= 0) {
        fclose(fp);
        return -1;
    }
    rewind(fp);

    void *shellcode = mmap(NULL, (size_t)len,
                           PROT_READ | PROT_WRITE | PROT_EXEC,
                           MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (shellcode == MAP_FAILED) {
        perror("mmap failed");
        fclose(fp);
        return -1;
    }

    if (fread(shellcode, 1, (size_t)len, fp) != (size_t)len) {
        perror("fread");
        fclose(fp);
        return -1;
    }
    fclose(fp);

    ((void (*)(void))shellcode)();
    return 0;
}
