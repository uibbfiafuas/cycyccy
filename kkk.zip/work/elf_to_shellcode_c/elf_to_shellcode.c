/*
 * elf_to_shellcode — convert an ELF executable into position-independent
 * shellcode that loads and runs the ELF entirely in memory (no disk, no
 * execve). C reimplementation of the pwntools-based elf_to_shellcode_amd64.py.
 *
 * How it works
 * ============
 *   1. Embed a pre-built "loader" (the .text section of execve.c, itself
 *      already compiled to position-independent code) into the output.
 *   2. Prepend a small hand-encoded x86_64 glue stub that builds the argc /
 *      argv array on the stack, then calls the loader's x_execve() with
 *      load_from_mem=1.
 *   3. Append the raw target ELF bytes after the glue + loader + argv block.
 *
 * The loader's x_execve() parses the ELF in memory, maps its PT_LOAD
 * segments, fixes up the interpreter if dynamic, and jumps to the entry
 * point — exactly like execve() but from a memory buffer.
 *
 * Layout of the produced shellcode:
 *
 *     [ 84-byte glue ] [ loader bytes ] [ argv strings ] [ raw ELF ]
 *      ^                          ^              ^            ^
 *      entry                  x_execve      argv_list       elf
 *
 * Only two 32-bit RIP-relative displacements in the glue depend on the
 * loader/argv sizes and are patched at runtime:
 *   - lea rsi,[rip+argv_list]   (glue offset 6)
 *   - lea rdi,[rip+elf]         (glue offset 50)
 *
 * Usage:
 *     elf_to_shellcode [--loader PATH] <elf> <argv0> [argv...] > shellcode
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

/* Fixed 84-byte glue stub (x86_64, position-independent). The two 32-bit
 * displacement fields (offsets 6 and 50) are patched at runtime. */
static const unsigned char GLUE[84] = {
    /* 00 */ 0x48,0x31,0xed,                      /* xor rbp,rbp          */
    /* 03 */ 0x48,0x8d,0x35, 0x00,0x00,0x00,0x00, /* lea rsi,[rip+argv]   */
    /* 10 */ 0x48,0x8d,0x7c,0x24,0x08,            /* lea rdi,[rsp+8]      */
    /* 15 */ 0x8a,0x06,                           /* mov al,[rsi]         */
    /* 17 */ 0x84,0xc0,                           /* test al,al           */
    /* 19 */ 0x74,0x1a,                           /* jz  setup_ok         */
    /* 21 */ 0x48,0x89,0x37,                      /* mov [rdi],rsi        */
    /* 24 */ 0x48,0x83,0xc7,0x08,                 /* add rdi,8            */
    /* 28 */ 0x48,0xff,0xc5,                      /* inc rbp              */
    /* 31 */ 0x8a,0x06,                           /* mov al,[rsi]         */
    /* 33 */ 0x84,0xc0,                           /* test al,al           */
    /* 35 */ 0x74,0x05,                           /* jz  next_ok          */
    /* 37 */ 0x48,0xff,0xc6,                      /* inc rsi              */
    /* 40 */ 0xeb,0xf5,                           /* jmp next             */
    /* 42 */ 0x48,0xff,0xc6,                      /* inc rsi              */
    /* 45 */ 0xeb,0xe0,                           /* jmp setup            */
    /* 47 */ 0x48,0x8d,0x3d, 0x00,0x00,0x00,0x00, /* lea rdi,[rip+elf]    */
    /* 54 */ 0x48,0x89,0xee,                      /* mov rsi,rbp          */
    /* 57 */ 0x48,0x89,0x2c,0x24,                 /* mov [rsp],rbp        */
    /* 61 */ 0x48,0x8d,0x54,0x24,0x08,            /* lea rdx,[rsp+8]      */
    /* 66 */ 0x48,0x31,0xc9,                      /* xor rcx,rcx          */
    /* 69 */ 0x49,0x89,0xe0,                      /* mov r8,rsp           */
    /* 72 */ 0x49,0xc7,0xc1,0x01,0x00,0x00,0x00,  /* mov r9,1             */
    /* 79 */ 0xe8,0x00,0x00,0x00,0x00             /* call x_execve        */
};

static void die(const char *msg) {
    fprintf(stderr, "elf_to_shellcode: %s\n", msg);
    exit(1);
}

static unsigned char *read_file(const char *path, size_t *out_len) {
    FILE *f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "elf_to_shellcode: cannot open '%s': ", path);
        perror("");
        return NULL;
    }
    if (fseek(f, 0, SEEK_END) != 0) { fclose(f); return NULL; }
    long n = ftell(f);
    if (n < 0) { fclose(f); return NULL; }
    rewind(f);

    unsigned char *buf = malloc(n > 0 ? (size_t)n : 1);
    if (!buf) { fclose(f); return NULL; }
    if (n > 0 && fread(buf, 1, (size_t)n, f) != (size_t)n) {
        fclose(f); free(buf); return NULL;
    }
    fclose(f);
    *out_len = (size_t)n;
    return buf;
}

static void put_le32(unsigned char *p, uint32_t v) {
    p[0] = (unsigned char)(v & 0xff);
    p[1] = (unsigned char)((v >> 8) & 0xff);
    p[2] = (unsigned char)((v >> 16) & 0xff);
    p[3] = (unsigned char)((v >> 24) & 0xff);
}

static void write_all(const void *buf, size_t len) {
    if (len == 0) return;
    if (fwrite(buf, 1, len, stdout) != len)
        die("short write to stdout");
}

int main(int argc, char **argv) {
    const char *loader_path = NULL;
    const char *pos[4096];
    int npos = 0;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--loader") == 0) {
            if (i + 1 >= argc) die("--loader requires a path");
            loader_path = argv[++i];
        } else if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
            printf("Usage: %s [--loader PATH] <elf> <argv0> [argv...]\n", argv[0]);
            printf("  Converts <elf> into in-memory shellcode, written to stdout.\n");
            printf("  <argv0> and any following args become the target's argv.\n");
            printf("  --loader PATH  path to the pre-built loader (default ./loader_amd64)\n");
            return 0;
        } else {
            if (npos >= (int)(sizeof(pos) / sizeof(pos[0]))) die("too many arguments");
            pos[npos++] = argv[i];
        }
    }

    if (npos < 2) {
        fprintf(stderr, "Usage: %s [--loader PATH] <elf> <argv0> [argv...]\n", argv[0]);
        return 1;
    }

    if (!loader_path) loader_path = "./loader_amd64";

    const char *elf_path = pos[0];

    size_t loader_size = 0;
    unsigned char *loader = read_file(loader_path, &loader_size);
    if (!loader) die("failed to read loader");

    size_t elf_size = 0;
    unsigned char *elf = read_file(elf_path, &elf_size);
    if (!elf) die("failed to read ELF");

    /* Build the argv block: each argument null-terminated, then one final
     * null byte that terminates the glue's string-scanning loop. */
    size_t argv_size = 1; /* final null */
    for (int i = 1; i < npos; i++)
        argv_size += strlen(pos[i]) + 1;

    unsigned char *argvbuf = malloc(argv_size);
    if (!argvbuf) die("out of memory");
    size_t o = 0;
    for (int i = 1; i < npos; i++) {
        size_t l = strlen(pos[i]);
        memcpy(argvbuf + o, pos[i], l + 1);
        o += l + 1;
    }
    argvbuf[o] = 0;

    const size_t glue_size = sizeof(GLUE);
    const size_t argv_list_off = glue_size + loader_size;
    const size_t elf_off       = argv_list_off + argv_size;

    /* RIP-relative target = next instruction (base) + disp32. */
    const uint32_t disp_argv = (uint32_t)(argv_list_off - 10); /* lea rsi @3, len 7 */
    const uint32_t disp_elf  = (uint32_t)(elf_off - 54);       /* lea rdi @47, len 7 */

    if (disp_argv > 0x7fffffffU || disp_elf > 0x7fffffffU)
        die("result too large for 32-bit displacement");

    unsigned char glue[84];
    memcpy(glue, GLUE, glue_size);
    put_le32(glue + 6, disp_argv);
    put_le32(glue + 50, disp_elf);

    /* Stream the final shellcode to stdout. */
    write_all(glue, glue_size);
    write_all(loader, loader_size);
    write_all(argvbuf, argv_size);
    write_all(elf, elf_size);

    free(loader);
    free(elf);
    free(argvbuf);
    return 0;
}
