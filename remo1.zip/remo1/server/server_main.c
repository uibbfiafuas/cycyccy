#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include "../lib/session.h"

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <port> [passphrase]\n", argv[0]);
        return 1;
    }
    signal(SIGPIPE, SIG_IGN);
    int port = atoi(argv[1]);
    const char *pass = (argc > 2) ? argv[2] : NULL;
    return server_session_shell(port, pass);
}
