#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include "../lib/session.h"

int main(int argc, char *argv[]) {
    if (argc < 3) {
        fprintf(stderr, "Usage: %s <server_ip> <port> [passphrase]\n", argv[0]);
        return 1;
    }
    signal(SIGPIPE, SIG_IGN);
    const char *ip = argv[1];
    int port = atoi(argv[2]);
    const char *pass = (argc > 3) ? argv[3] : NULL;
    return client_session_shell(ip, port, pass);
}
