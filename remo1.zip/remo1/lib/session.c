#define _GNU_SOURCE
#include "session.h"
#include "aes.h"
#include "protocol.h"
#include "tcp_client.h"
#include "tcp_server.h"
#include "file_mgr.h"

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/wait.h>

/* ========================================================================
 * Internal utility functions
 * ======================================================================== */

static const char *resolve_passphrase(const char *passphrase) {
    if (passphrase && passphrase[0]) return passphrase;
    const char *env = getenv(REMO2_PASSPHRASE_ENV);
    return env ? env : REMO2_DEFAULT_PASSPHRASE;
}

static ssize_t read_full(int fd, void *buf, size_t len) {
    size_t done = 0;
    unsigned char *p = (unsigned char *)buf;
    while (done < len) {
        ssize_t r = read(fd, p + done, len - done);
        if (r < 0) { if (errno == EINTR) continue; return -1; }
        if (r == 0) return 0;
        done += (size_t)r;
    }
    return (ssize_t)done;
}

static int write_full(int fd, const void *buf, size_t len) {
    size_t done = 0;
    const unsigned char *p = (const unsigned char *)buf;
    while (done < len) {
        ssize_t w = write(fd, p + done, len - done);
        if (w < 0) { if (errno == EINTR) continue; return -1; }
        done += (size_t)w;
    }
    return 0;
}

static void random_iv(uint8_t iv[12]) {
    FILE *f = fopen("/dev/urandom", "rb");
    if (!f) { for (int i = 0; i < 12; i++) iv[i] = (uint8_t)(rand() % 256); return; }
    (void)!fread(iv, 1, 12, f);
    fclose(f);
}

/* ========================================================================
 * Encrypted frame send/recv
 * ======================================================================== */

// Non-static so file_mgr can use it via the fm_send_fn callback
int session_send_encrypted(int sock, const uint8_t *key, uint8_t stream_id,
                           const task_frame_t *frame) {
    packet_header_t header;
    uint8_t ciphertext[sizeof(task_frame_t)];
    memset(&header, 0, sizeof(header));
    header.meta.magic       = htonl(REMO2_MAGIC);
    header.meta.version     = REMO2_VERSION;
    header.meta.stream_id   = stream_id;
    header.meta.reserved    = 0;
    header.meta.seq         = htonl(frame->seq);
    header.meta.payload_len = htonl((uint32_t)sizeof(*frame));
    random_iv(header.iv);

    if (aes_gcm_encrypt(key,
                        (const uint8_t *)&header.meta, sizeof(header.meta),
                        (const uint8_t *)frame, sizeof(*frame),
                        header.iv, ciphertext, header.tag) != 0) {
        fprintf(stderr, "aes_gcm_encrypt failed\n");
        return -1;
    }
    if (write_full(sock, &header, sizeof(header)) < 0) return -1;
    if (write_full(sock, ciphertext, sizeof(ciphertext)) < 0) return -1;
    return 0;
}

static int recv_decrypted_frame(int sock, const uint8_t *key,
                                uint8_t *stream_id, task_frame_t *frame) {
    packet_header_t header;
    ssize_t r = read_full(sock, &header, sizeof(header));
    if (r == 0) return 0;
    if (r < 0) { perror("read header"); return -1; }
    if (ntohl(header.meta.magic) != REMO2_MAGIC || header.meta.version != REMO2_VERSION) {
        fprintf(stderr, "invalid packet header\n"); return -1;
    }
    uint32_t payload_len = ntohl(header.meta.payload_len);
    if (payload_len != sizeof(task_frame_t)) {
        fprintf(stderr, "unexpected payload length: %u\n", payload_len); return -1;
    }
    uint8_t ciphertext[sizeof(task_frame_t)];
    r = read_full(sock, ciphertext, sizeof(ciphertext));
    if (r == 0) return 0;
    if (r < 0) { perror("read ciphertext"); return -1; }
    memset(frame, 0, sizeof(*frame));
    if (aes_gcm_decrypt(key,
                        (const uint8_t *)&header.meta, sizeof(header.meta),
                        ciphertext, sizeof(ciphertext),
                        header.iv, header.tag,
                        (uint8_t *)frame) != 0) {
        fprintf(stderr, "aes_gcm_decrypt failed (tag mismatch)\n");
        return -1;
    }
    *stream_id = header.meta.stream_id;
    return 1;
}

// Send SHELL stream frame
static void send_shell_frame(int sock, const uint8_t *key,
                             uint32_t *seq, uint8_t task_id,
                             const void *data, size_t len) {
    task_frame_t frame;
    memset(&frame, 0, sizeof(frame));
    frame.task_id = task_id;
    frame.seq     = (*seq)++;
    if (len > REMO2_TEXT_LEN) len = REMO2_TEXT_LEN;
    memcpy(frame.text, data, len);
    session_send_encrypted(sock, key, REMO2_STREAM_SHELL, &frame);
}

/* ========================================================================
 * Send buffer (dynamic resize) — for non-blocking SHELL writes
 * ======================================================================== */

typedef struct {
    unsigned char *buf;
    size_t size, head, tail;
} send_buffer_t;

static void sb_init(send_buffer_t *sb) { sb->buf = NULL; sb->size = sb->head = sb->tail = 0; }
static void sb_free(send_buffer_t *sb)  { free(sb->buf); sb_init(sb); }
static size_t sb_data_len(const send_buffer_t *sb) { return sb->tail - sb->head; }
static const unsigned char *sb_data_ptr(const send_buffer_t *sb) { return sb->buf + sb->head; }

static int sb_append(send_buffer_t *sb, const void *data, size_t len) {
    if (sb->tail + len > sb->size) {
        size_t new_size = sb->size ? sb->size * 2 : 4096;
        while (new_size < sb->tail + len) new_size *= 2;
        unsigned char *new_buf = realloc(sb->buf, new_size);
        if (!new_buf) return -1;
        sb->buf  = new_buf;
        sb->size = new_size;
    }
    memcpy(sb->buf + sb->tail, data, len);
    sb->tail += len;
    return 0;
}

static void sb_discard(send_buffer_t *sb, size_t len) {
    sb->head += len;
    if (sb->head == sb->tail) sb->head = sb->tail = 0;
}

/* ========================================================================
 * CLIENT: poll main loop
 * ======================================================================== */

int client_session_shell(const char *ip, int port, const char *passphrase) {
    const char *pw = resolve_passphrase(passphrase);
    uint8_t key[REMO2_AES_KEY_LEN];
    if (aes_derive_key(pw, key) != 0) { fprintf(stderr, "aes_derive_key failed\n"); return 1; }

    int sock = tcp_client_connect(ip, port);
    if (sock < 0) return 1;

    int shell_to_net[2], net_to_shell[2];
    if (socketpair(AF_UNIX, SOCK_STREAM, 0, shell_to_net) < 0 ||
        socketpair(AF_UNIX, SOCK_STREAM, 0, net_to_shell) < 0) {
        perror("socketpair"); tcp_client_close(sock); return 1;
    }

    pid_t shell_pid = fork();
    if (shell_pid == 0) {
        close(sock);
        close(shell_to_net[0]); close(net_to_shell[1]);
        dup2(shell_to_net[1], STDOUT_FILENO);
        dup2(shell_to_net[1], STDERR_FILENO);
        dup2(net_to_shell[0],  STDIN_FILENO);
        close(shell_to_net[1]); close(net_to_shell[0]);
        execl("/bin/sh", "sh", "-i", NULL);
        perror("execl"); exit(1);
    }
    close(shell_to_net[1]); close(net_to_shell[0]);

    int flags = fcntl(net_to_shell[1], F_GETFL, 0);
    if (flags != -1) fcntl(net_to_shell[1], F_SETFL, flags | O_NONBLOCK);
    signal(SIGPIPE, SIG_IGN);

    send_buffer_t send_buf;
    sb_init(&send_buf);

    // Initialize file manager
    fm_poll_array_t fm_pa;
    fm_pa_init(&fm_pa);
    fm_ctx_t fm;
    fm_init(&fm, sock, key, session_send_encrypted, &fm_pa);

    // Build poll array
    fm_poll_array_t *pa = &fm_pa;
    int sock_idx       = fm_pa_add(pa, sock,            POLLIN);
    int shell_out_idx  = fm_pa_add(pa, shell_to_net[0], POLLIN);
    int shell_in_idx   = fm_pa_add(pa, net_to_shell[1], 0);
    (void)sock_idx; (void)shell_out_idx; (void)shell_in_idx;

    uint32_t seq_out = 0;
    char buffer[REMO2_TEXT_LEN];
    int running = 1;

    while (running) {
        pa->items[shell_in_idx].events = (sb_data_len(&send_buf) > 0) ? POLLOUT : 0;

        int ret = poll(pa->items, pa->count, 50);
        if (ret < 0) { if (errno == EINTR) continue; perror("poll"); break; }

        // [1] Shell output -> network
        if (pa->items[shell_out_idx].revents & POLLIN) {
            ssize_t n = read(shell_to_net[0], buffer, REMO2_TEXT_LEN);
            if (n > 0) {
                send_shell_frame(sock, key, &seq_out, REMO2_SHELL_TASK_OUT, buffer, (size_t)n);
            } else { running = 0; break; }
        }

        // [2] Network data -> L1 dispatch
        if (pa->items[sock_idx].revents & POLLIN) {
            task_frame_t frame;
            uint8_t sid;
            int res = recv_decrypted_frame(sock, key, &sid, &frame);
            if (res <= 0) { running = 0; break; }

            switch (sid) {
            case REMO2_STREAM_SHELL:
                if (frame.task_id == REMO2_SHELL_TASK_IN) {
                    size_t len = strnlen(frame.text, REMO2_TEXT_LEN);
                    if (len > 0) sb_append(&send_buf, frame.text, len);
                }
                break;
            case REMO2_STREAM_FILE:
                fm_client_dispatch(&fm, &seq_out, &frame);
                break;
            default: break;
            }
        }

        // [3] Flush shell input buffer
        if (pa->items[shell_in_idx].revents & POLLOUT) {
            while (sb_data_len(&send_buf) > 0) {
                ssize_t nw = write(net_to_shell[1], sb_data_ptr(&send_buf), sb_data_len(&send_buf));
                if (nw > 0) {
                    sb_discard(&send_buf, nw);
                } else if (nw < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
                    break;
                } else if (nw < 0 && errno == EPIPE) {
                    running = 0; break;
                } else if (nw < 0) {
                    perror("write shell pipe"); running = 0; break;
                }
            }
        }

        // [4] Flush file downloads
        fm_client_flush_downloads(&fm, &seq_out);

        if (pa->items[shell_out_idx].revents & (POLLERR | POLLHUP)) running = 0;
        if (pa->items[sock_idx].revents      & (POLLERR | POLLHUP)) running = 0;
    }

    close(sock);
    close(shell_to_net[0]); close(net_to_shell[1]);
    sb_free(&send_buf);
    fm_cleanup(&fm);
    kill(shell_pid, SIGTERM);
    waitpid(shell_pid, NULL, 0);
    return 0;
}

/* ========================================================================
 * SERVER: command line parser
 * ======================================================================== */

static int parse_file_cmd(const char *input, int input_len,
                          uint8_t *op, char *path, int path_size) {
    if (input_len < 3 || memcmp(input, "!!", 2) != 0) return 0;
    const char *cs = input + 2;
    int cl = input_len - 2;

    #define EXTRACT(start, rem, buf, sz) do { \
        const char *_p = (start); int _r = (rem); \
        const char *_sp = memchr(_p, ' ', _r); \
        int _l = _sp ? (int)(_sp - _p) : _r; \
        if (_l > (sz)-1) _l = (sz)-1; \
        memcpy((buf), _p, _l); (buf)[_l] = '\0'; \
        while ((buf)[0] && ((buf)[strlen(buf)-1]=='\n' || (buf)[strlen(buf)-1]=='\r')) \
            (buf)[strlen(buf)-1] = '\0'; \
        (start) = _sp ? _sp + 1 : _p + _r; \
        (rem)   = _sp ? _r - _l - 1 : 0; \
    } while(0)

    if (cl > 8 && memcmp(cs, "download ", 9) == 0) {
        *op = REMO2_FILE_OP_DOWNLOAD;
        const char *p = cs + 9; int r = cl - 9;
        char src[REMO2_FILE_MAX_NAME], dst[REMO2_FILE_MAX_NAME] = "";
        EXTRACT(p, r, src, sizeof(src));
        if (r > 0) EXTRACT(p, r, dst, sizeof(dst));
        int sl = (int)strlen(src); memcpy(path, src, sl + 1);
        if (dst[0]) memcpy(path + sl + 1, dst, strlen(dst) + 1);
        else path[sl + 1] = '\0';
        return 1;
    }
    if (cl > 6 && memcmp(cs, "upload ", 7) == 0) {
        *op = REMO2_FILE_OP_UPLOAD;
        const char *p = cs + 7; int r = cl - 7;
        char src[REMO2_FILE_MAX_NAME], dst[REMO2_FILE_MAX_NAME] = "";
        EXTRACT(p, r, src, sizeof(src));
        if (r > 0) EXTRACT(p, r, dst, sizeof(dst));
        int sl = (int)strlen(src); memcpy(path, src, sl + 1);
        if (dst[0]) memcpy(path + sl + 1, dst, strlen(dst) + 1);
        else path[sl + 1] = '\0';
        return 1;
    }
    #undef EXTRACT

    if (cl > 4 && memcmp(cs, "list ", 5) == 0) {
        *op = REMO2_FILE_OP_LIST;
        int pl = cl - 5;
        memcpy(path, cs + 5, pl < path_size - 1 ? (size_t)pl : (size_t)(path_size - 1));
        path[pl < path_size - 1 ? pl : path_size - 1] = '\0';
        while (path[0] && (path[strlen(path)-1]=='\n' || path[strlen(path)-1]=='\r'))
            path[strlen(path)-1] = '\0';
        return 1;
    }
    if (cl >= 4 && memcmp(cs, "list", 4) == 0 && (cl == 4 || cs[4]=='\n' || cs[4]=='\r')) {
        *op = REMO2_FILE_OP_LIST; path[0]='.'; path[1]='\0'; return 1;
    }
    if (cl >= 2 && memcmp(cs, "ls", 2) == 0 && (cl == 2 || cs[2]=='\n' || cs[2]=='\r' || cs[2]==' ')) {
        *op = REMO2_FILE_OP_LIST;
        int pl = (cl > 2 && cs[2]==' ') ? cl - 3 : 0;
        if (pl > 0) {
            memcpy(path, cs+3, pl < path_size-1 ? (size_t)pl : (size_t)(path_size-1));
            path[pl < path_size-1 ? pl : path_size-1] = '\0';
            while (path[0] && (path[strlen(path)-1]=='\n' || path[strlen(path)-1]=='\r'))
                path[strlen(path)-1] = '\0';
        } else { path[0]='.'; path[1]='\0'; }
        return 1;
    }
    if (cl > 6 && memcmp(cs, "delete ", 7) == 0) {
        *op = REMO2_FILE_OP_DELETE;
        int pl = cl - 7;
        memcpy(path, cs+7, pl < path_size-1 ? (size_t)pl : (size_t)(path_size-1));
        path[pl < path_size-1 ? pl : path_size-1] = '\0';
        while (path[0] && (path[strlen(path)-1]=='\n' || path[strlen(path)-1]=='\r'))
            path[strlen(path)-1] = '\0';
        return 1;
    }
    return 0;
}

/* ========================================================================
 * SERVER: poll main loop
 * ======================================================================== */

int server_session_shell(int port, const char *passphrase) {
    const char *pw = resolve_passphrase(passphrase);
    uint8_t key[REMO2_AES_KEY_LEN];
    if (aes_derive_key(pw, key) != 0) { fprintf(stderr, "aes_derive_key failed\n"); return 1; }

    int listen_fd = tcp_server_listen(port);
    if (listen_fd < 0) return 1;
    printf("[server] listening on port %d ...\n", port);
    int cli_fd = tcp_server_accept(listen_fd);
    tcp_server_close(listen_fd);
    if (cli_fd < 0) return 1;
    printf("[server] client connected.\n");
    printf("[server] !!ls [dir] | !!download <remote> [local] | !!upload <local> [remote] | !!delete <remote>\n\n");

    // Initialize file manager (server-side: no poll array needed)
    fm_ctx_t fm;
    fm_init(&fm, cli_fd, key, session_send_encrypted, NULL);

    struct pollfd pfds[2];
    pfds[0].fd     = cli_fd;
    pfds[0].events = POLLIN;
    pfds[1].fd     = STDIN_FILENO;
    pfds[1].events = POLLIN;

    uint32_t seq_in  = 0;
    char line_buf[REMO2_TEXT_LEN];
    int  line_len = 0;
    int  running  = 1;

    while (running) {
        int ret = poll(pfds, 2, 100);
        if (ret < 0) { if (errno == EINTR) continue; perror("poll"); break; }

        // [1] Network data -> L1 dispatch
        if (pfds[0].revents & POLLIN) {
            task_frame_t frame;
            uint8_t sid;
            int res = recv_decrypted_frame(cli_fd, key, &sid, &frame);
            if (res <= 0) { printf("\n[server] connection closed.\n"); break; }

            switch (sid) {
            case REMO2_STREAM_SHELL:
                if (frame.task_id == REMO2_SHELL_TASK_OUT) {
                    fwrite(frame.text, 1, strnlen(frame.text, REMO2_TEXT_LEN), stdout);
                    fflush(stdout);
                }
                break;
            case REMO2_STREAM_FILE:
                fm_server_dispatch(&fm, &frame);
                break;
            default: break;
            }
        }

        // [2] Local keyboard input -> line buffer
        if (pfds[1].revents & POLLIN) {
            char raw[REMO2_TEXT_LEN];
            ssize_t n = read(STDIN_FILENO, raw, sizeof(raw) - 1);
            if (n <= 0) { running = 0; break; }

            for (ssize_t i = 0; i < n; i++) {
                line_buf[line_len++] = raw[i];
                if (raw[i] == '\n' || line_len >= (int)sizeof(line_buf) - 1) {
                    line_buf[line_len] = '\0';
                    int llen = line_len;
                    line_len = 0;

                    uint8_t op;
                    char path_buf[REMO2_FILE_MAX_NAME];
                    if (parse_file_cmd(line_buf, llen, &op, path_buf, sizeof(path_buf))) {
                        const char *psrc = path_buf;
                        const char *pdst = psrc + strlen(psrc) + 1;
                        if ((size_t)(pdst - path_buf) >= sizeof(path_buf)) pdst = "";
                        fm_server_prepare_cmd(&fm, &seq_in, op, psrc, pdst);
                    } else {
                        send_shell_frame(cli_fd, key, &seq_in, REMO2_SHELL_TASK_IN,
                                         line_buf, (size_t)llen);
                    }
                    if (raw[i] != '\n') break;
                }
            }
        }

        // [3] Flush upload data
        fm_server_flush_uploads(&fm, &seq_in);
    }

    tcp_server_close(cli_fd);
    fm_cleanup(&fm);
    return 0;
}
