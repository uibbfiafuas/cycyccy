#include "session.h"
#include "aes.h"
#include "protocol.h"
#include "tcp_client.h"
#include "tcp_server.h"

#include <arpa/inet.h>
#include <errno.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/wait.h>

static const char *resolve_passphrase(const char *passphrase) {
    if (passphrase && passphrase[0]) return passphrase;
    const char *env = getenv(REMO2_PASSPHRASE_ENV);
    return env ? env : REMO2_DEFAULT_PASSPHRASE;
}

static ssize_t read_full(int fd, void *buf, size_t len) {
    size_t done = 0;
    unsigned char *p = (unsigned char *)buf;
    while (done < len) {
        ssize_t r = read(fd, p + done, len - done);
        if (r < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (r == 0) return 0;
        done += (size_t)r;
    }
    return (ssize_t)done;
}

static int write_full(int fd, const void *buf, size_t len) {
    size_t done = 0;
    const unsigned char *p = (const unsigned char *)buf;
    while (done < len) {
        ssize_t w = write(fd, p + done, len - done);
        if (w < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        done += (size_t)w;
    }
    return 0;
}

static void random_iv(uint8_t iv[12]) {
    FILE *f = fopen("/dev/urandom", "rb");
    if (!f) {
        for (int i = 0; i < 12; i++) iv[i] = (uint8_t)(rand() % 256);
        return;
    }
    fread(iv, 1, 12, f);
    fclose(f);
}

static int send_encrypted_frame(int sock, const uint8_t key[REMO2_AES_KEY_LEN],
                                const task_frame_t *frame) {
    packet_header_t header;
    uint8_t ciphertext[sizeof(task_frame_t)];
    memset(&header, 0, sizeof(header));
    header.meta.magic = htonl(REMO2_MAGIC);
    header.meta.version = REMO2_VERSION;
    header.meta.stream_id = (uint8_t)frame->task_id;
    header.meta.reserved = 0;
    header.meta.seq = htonl(frame->seq);
    header.meta.payload_len = htonl((uint32_t)sizeof(*frame));
    random_iv(header.iv);

    if (aes_gcm_encrypt(key,
                        (const uint8_t *)&header.meta, sizeof(header.meta),
                        (const uint8_t *)frame, sizeof(*frame),
                        header.iv,
                        ciphertext, header.tag) != 0) {
        fprintf(stderr, "aes_gcm_encrypt failed\n");
        return -1;
    }
    if (write_full(sock, &header, sizeof(header)) < 0) return -1;
    if (write_full(sock, ciphertext, sizeof(ciphertext)) < 0) return -1;
    return 0;
}

static int recv_decrypted_frame(int sock, const uint8_t key[REMO2_AES_KEY_LEN],
                                task_frame_t *frame) {
    packet_header_t header;
    ssize_t r = read_full(sock, &header, sizeof(header));
    if (r == 0) return 0;
    if (r < 0) { perror("read header"); return -1; }
    if (ntohl(header.meta.magic) != REMO2_MAGIC || header.meta.version != REMO2_VERSION) {
        fprintf(stderr, "invalid packet header\n"); return -1;
    }
    uint32_t payload_len = ntohl(header.meta.payload_len);
    if (payload_len != sizeof(task_frame_t)) {
        fprintf(stderr, "unexpected payload length\n"); return -1;
    }
    uint8_t ciphertext[sizeof(task_frame_t)];
    r = read_full(sock, ciphertext, sizeof(ciphertext));
    if (r == 0) return 0;
    if (r < 0) { perror("read ciphertext"); return -1; }
    memset(frame, 0, sizeof(*frame));
    if (aes_gcm_decrypt(key,
                        (const uint8_t *)&header.meta, sizeof(header.meta),
                        ciphertext, sizeof(ciphertext),
                        header.iv, header.tag,
                        (uint8_t *)frame) != 0) {
        fprintf(stderr, "aes_gcm_decrypt failed (tag mismatch)\n");
        return -1;
    }
    return sizeof(header) + sizeof(ciphertext);
}

int client_session_shell(const char *ip, int port, const char *passphrase) {
    const char *pw = resolve_passphrase(passphrase);
    uint8_t key[REMO2_AES_KEY_LEN];
    if (aes_derive_key(pw, key) != 0) {
        fprintf(stderr, "aes_derive_key failed\n");
        return 1;
    }
    int sock = tcp_client_connect(ip, port);
    if (sock < 0) return 1;

    int shell_to_net[2];
    int net_to_shell[2];
    if (socketpair(AF_UNIX, SOCK_STREAM, 0, shell_to_net) < 0 ||
        socketpair(AF_UNIX, SOCK_STREAM, 0, net_to_shell) < 0) {
        perror("socketpair"); tcp_client_close(sock); return 1;
    }

    pid_t pid = fork();
    if (pid == 0) {
        close(sock);
        close(shell_to_net[0]);
        close(net_to_shell[1]);
        dup2(shell_to_net[1], STDOUT_FILENO);
        dup2(shell_to_net[1], STDERR_FILENO);
        dup2(net_to_shell[0], STDIN_FILENO);
        close(shell_to_net[1]);
        close(net_to_shell[0]);
        execl("/bin/sh", "sh", "-i", NULL);
        perror("execl"); exit(1);
    }
    close(shell_to_net[1]);
    close(net_to_shell[0]);

    struct pollfd pfds[2];
    pfds[0].fd = sock;
    pfds[0].events = POLLIN;
    pfds[1].fd = shell_to_net[0];
    pfds[1].events = POLLIN;

    uint32_t seq_out = 0;
    char buffer[REMO2_TEXT_LEN];
    int running = 1;

    while (running) {
        if (poll(pfds, 2, -1) < 0) {
            if (errno == EINTR) continue;
            perror("poll"); break;
        }
        if (pfds[1].revents & POLLIN) {
            ssize_t n = read(shell_to_net[0], buffer, REMO2_TEXT_LEN);
            if (n > 0) {
                task_frame_t frame;
                memset(&frame, 0, sizeof(frame));
                frame.task_id = 0;
                frame.seq = seq_out++;
                memcpy(frame.text, buffer, n);
                if (send_encrypted_frame(sock, key, &frame) != 0) break;
            } else {
                running = 0;
                break;
            }
        }
        if (pfds[0].revents & POLLIN) {
            task_frame_t frame;
            int res = recv_decrypted_frame(sock, key, &frame);
            if (res == 0) { running = 0; break; }
            if (res < 0) break;
            if (frame.task_id == 1) {
                size_t len = strnlen(frame.text, REMO2_TEXT_LEN);
                if (write_full(net_to_shell[1], frame.text, len) < 0) break;
            }
        }
    }

    close(sock);
    close(shell_to_net[0]);
    close(net_to_shell[1]);
    kill(pid, SIGTERM);
    waitpid(pid, NULL, 0);
    return 0;
}

int server_session_shell(int port, const char *passphrase) {
    const char *pw = resolve_passphrase(passphrase);
    uint8_t key[REMO2_AES_KEY_LEN];
    if (aes_derive_key(pw, key) != 0) {
        fprintf(stderr, "aes_derive_key failed\n");
        return 1;
    }
    int listen_fd = tcp_server_listen(port);
    if (listen_fd < 0) return 1;
    printf("[server] listening on port %d ...\n", port);
    int client_fd = tcp_server_accept(listen_fd);
    tcp_server_close(listen_fd);
    if (client_fd < 0) return 1;
    printf("[server] client connected.\n");

    struct pollfd pfds[2];
    pfds[0].fd = client_fd;
    pfds[0].events = POLLIN;
    pfds[1].fd = STDIN_FILENO;
    pfds[1].events = POLLIN;

    uint32_t seq_in = 0;
    char buffer[REMO2_TEXT_LEN];
    int running = 1;

    while (running) {
        if (poll(pfds, 2, -1) < 0) {
            if (errno == EINTR) continue;
            perror("poll"); break;
        }
        if (pfds[0].revents & POLLIN) {
            task_frame_t frame;
            int res = recv_decrypted_frame(client_fd, key, &frame);
            if (res == 0) { printf("\n[server] connection closed.\n"); break; }
            if (res < 0) break;
            if (frame.task_id == 0) {
                fwrite(frame.text, 1, strnlen(frame.text, REMO2_TEXT_LEN), stdout);
                fflush(stdout);
            }
        }
        if (pfds[1].revents & POLLIN) {
            ssize_t n = read(STDIN_FILENO, buffer, REMO2_TEXT_LEN);
            if (n > 0) {
                task_frame_t frame;
                memset(&frame, 0, sizeof(frame));
                frame.task_id = 1;
                frame.seq = seq_in++;
                memcpy(frame.text, buffer, n);
                if (send_encrypted_frame(client_fd, key, &frame) != 0) break;
            } else {
                running = 0;
                break;
            }
        }
    }

    tcp_server_close(client_fd);
    return 0;
}
