#include "aes.h"
#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/kdf.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

static void handle_errors(void) {
    ERR_print_errors_fp(stderr);
    abort();
}

int aes_derive_key(const char *passphrase, uint8_t key[REMO2_AES_KEY_LEN]) {
    const char salt[] = "remo2-static-salt";
    EVP_PKEY_CTX *pctx = EVP_PKEY_CTX_new_id(EVP_PKEY_HKDF, NULL);
    if (!pctx) return -1;
    if (EVP_PKEY_derive_init(pctx) <= 0) { EVP_PKEY_CTX_free(pctx); return -1; }
    if (EVP_PKEY_CTX_hkdf_mode(pctx, EVP_PKEY_HKDEF_MODE_EXTRACT_AND_EXPAND) <= 0) {
        EVP_PKEY_CTX_free(pctx); return -1;
    }
    if (EVP_PKEY_CTX_set_hkdf_md(pctx, EVP_sha256()) <= 0) {
        EVP_PKEY_CTX_free(pctx); return -1;
    }
    if (EVP_PKEY_CTX_set1_hkdf_salt(pctx, (unsigned char*)salt, strlen(salt)) <= 0) {
        EVP_PKEY_CTX_free(pctx); return -1;
    }
    if (EVP_PKEY_CTX_set1_hkdf_key(pctx, (unsigned char*)passphrase, strlen(passphrase)) <= 0) {
        EVP_PKEY_CTX_free(pctx); return -1;
    }
    size_t out_len = REMO2_AES_KEY_LEN;
    if (EVP_PKEY_derive(pctx, key, &out_len) <= 0) {
        EVP_PKEY_CTX_free(pctx); return -1;
    }
    EVP_PKEY_CTX_free(pctx);
    return 0;
}

int aes_gcm_encrypt(const uint8_t key[REMO2_AES_KEY_LEN],
                    const uint8_t *aad, size_t aad_len,
                    const uint8_t *plaintext, size_t plaintext_len,
                    const uint8_t iv[12],
                    uint8_t *ciphertext,
                    uint8_t tag[16]) {
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx) return -1;
    int len = 0, ciphertext_len = 0;

    if (1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL)) {
        EVP_CIPHER_CTX_free(ctx); handle_errors();
    }
    if (1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, 12, NULL)) {
        EVP_CIPHER_CTX_free(ctx); handle_errors();
    }
    if (1 != EVP_EncryptInit_ex(ctx, NULL, NULL, key, iv)) {
        EVP_CIPHER_CTX_free(ctx); handle_errors();
    }
    if (aad_len > 0) {
        if (1 != EVP_EncryptUpdate(ctx, NULL, &len, aad, aad_len)) {
            EVP_CIPHER_CTX_free(ctx); handle_errors();
        }
    }
    if (1 != EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len)) {
        EVP_CIPHER_CTX_free(ctx); handle_errors();
    }
    ciphertext_len = len;
    if (1 != EVP_EncryptFinal_ex(ctx, ciphertext + len, &len)) {
        EVP_CIPHER_CTX_free(ctx); handle_errors();
    }
    ciphertext_len += len;
    if (1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, 16, tag)) {
        EVP_CIPHER_CTX_free(ctx); handle_errors();
    }
    EVP_CIPHER_CTX_free(ctx);
    return (ciphertext_len == (int)plaintext_len) ? 0 : -1;
}

int aes_gcm_decrypt(const uint8_t key[REMO2_AES_KEY_LEN],
                    const uint8_t *aad, size_t aad_len,
                    const uint8_t *ciphertext, size_t ciphertext_len,
                    const uint8_t iv[12],
                    const uint8_t tag[16],
                    uint8_t *plaintext) {
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx) return -1;
    int len = 0, plaintext_len = 0;

    if (1 != EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL)) {
        EVP_CIPHER_CTX_free(ctx); handle_errors();
    }
    if (1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, 12, NULL)) {
        EVP_CIPHER_CTX_free(ctx); handle_errors();
    }
    if (1 != EVP_DecryptInit_ex(ctx, NULL, NULL, key, iv)) {
        EVP_CIPHER_CTX_free(ctx); handle_errors();
    }
    if (aad_len > 0) {
        if (1 != EVP_DecryptUpdate(ctx, NULL, &len, aad, aad_len)) {
            EVP_CIPHER_CTX_free(ctx); handle_errors();
        }
    }
    if (1 != EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len)) {
        EVP_CIPHER_CTX_free(ctx); handle_errors();
    }
    plaintext_len = len;
    if (1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, 16, (void*)tag)) {
        EVP_CIPHER_CTX_free(ctx); handle_errors();
    }
    if (1 != EVP_DecryptFinal_ex(ctx, plaintext + len, &len)) {
        EVP_CIPHER_CTX_free(ctx); return -1;
    }
    plaintext_len += len;
    EVP_CIPHER_CTX_free(ctx);
    return (plaintext_len == (int)ciphertext_len) ? 0 : -1;
}
