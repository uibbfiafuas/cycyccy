#ifndef REMO2_PROTOCOL_H
#define REMO2_PROTOCOL_H

#include <stdint.h>

#define REMO2_MAGIC          0x52454d32u
#define REMO2_VERSION        1
#define REMO2_TASK_COUNT     2
#define REMO2_TEXT_LEN       160

#define REMO2_DEFAULT_PORT       9000
#define REMO2_DEFAULT_PASSPHRASE "remo2-demo-shared-secret"
#define REMO2_PASSPHRASE_ENV     "REMO2_AES_PASSPHRASE"

typedef struct __attribute__((packed)) {
    uint32_t task_id;
    uint32_t seq;
    char text[REMO2_TEXT_LEN];
} task_frame_t;

typedef struct __attribute__((packed)) {
    uint32_t magic;
    uint8_t  version;
    uint8_t  stream_id;
    uint16_t reserved;
    uint32_t seq;
    uint32_t payload_len;
} packet_meta_t;

typedef struct __attribute__((packed)) {
    packet_meta_t meta;
    uint8_t iv[12];
    uint8_t tag[16];
} packet_header_t;

#endif
