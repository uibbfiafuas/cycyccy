#ifndef REMO2_PROTOCOL_H
#define REMO2_PROTOCOL_H

#include <stdint.h>

#define REMO2_MAGIC          0x52454d32u
#define REMO2_VERSION        1

#define REMO2_TEXT_LEN       160
#define REMO2_FILE_DATA_MAX  140
#define REMO2_FILE_MAX_NAME  128

#define REMO2_DEFAULT_PORT       9000
#define REMO2_DEFAULT_PASSPHRASE "remo2-demo-shared-secret"
#define REMO2_PASSPHRASE_ENV     "REMO2_AES_PASSPHRASE"

/* ============================================================
 * L1 routing: stream_id — selects the business module
 * ============================================================ */
#define REMO2_STREAM_SHELL    0   // Shell interactive module
#define REMO2_STREAM_FILE     1   // File management module

/* ============================================================
 * L2 routing (Shell): task_id — direction indicator
 * ============================================================ */
#define REMO2_SHELL_TASK_OUT  0   // Shell output (child -> remote)
#define REMO2_SHELL_TASK_IN   1   // Shell input  (remote -> child)

/* ============================================================
 * L2 routing (File): op — operation code
 *   OPs (1-15): commands and data
 *   Status (0x80+): response codes, no collision with OPs
 * ============================================================ */
#define REMO2_FILE_OP_LIST     1   // List directory
#define REMO2_FILE_OP_DOWNLOAD 2   // Download (remote -> local)
#define REMO2_FILE_OP_UPLOAD   3   // Upload (local -> remote)
#define REMO2_FILE_OP_DELETE   4   // Delete file
#define REMO2_FILE_OP_DATA     5   // Data transfer chunk

#define REMO2_FILE_OK          0x80  // Operation succeeded
#define REMO2_FILE_ERR_OPEN    0x81  // File open failed
#define REMO2_FILE_ERR_IO      0x82  // I/O error

#define REMO2_FILE_SLOTS       4     // Max concurrent file transfer slots

/* ============================================================
 * Protocol structs
 * ============================================================ */

/* task_frame: carries payload for all business modules
 *   - task_id: L2 key (SHELL: IN/OUT direction, FILE: reserved)
 *   - seq: sequence number (anti-replay)
 *   - text: payload (SHELL: raw text, FILE: cast to file_frame_t)
 */
typedef struct __attribute__((packed)) {
    uint32_t task_id;               // L2 routing key
    uint32_t seq;
    char text[REMO2_TEXT_LEN];      // SHELL: raw text / FILE: file_frame_t
} task_frame_t;

/* packet_meta: L1 routing (stream_id selects module) */
typedef struct __attribute__((packed)) {
    uint32_t magic;                 // REMO2_MAGIC
    uint8_t  version;               // protocol version
    uint8_t  stream_id;             // L1 routing key: 0=SHELL, 1=FILE
    uint16_t reserved;
    uint32_t seq;
    uint32_t payload_len;           // = sizeof(task_frame_t)
} packet_meta_t;

/* packet_header: cleartext header + crypto material (AAD=packet_meta) */
typedef struct __attribute__((packed)) {
    packet_meta_t meta;             // cleartext, used as GCM AAD
    uint8_t iv[12];                 // random initialization vector
    uint8_t tag[16];                // GCM authentication tag
} packet_header_t;

/* file_frame: FILE module payload structure
 *   Embedded in task_frame.text[0..sizeof(file_frame_t)]
 *   op distinguishes LIST/DOWNLOAD/UPLOAD/DELETE/DATA
 *   DOWNLOAD/UPLOAD use offset+data_len+data for chunked transfer
 *   LIST response fills data with directory listing
 */
typedef struct __attribute__((packed)) {
    uint8_t  op;                        // file op code
    uint8_t  request_id;                // concurrent request ID
    uint16_t reserved;
    uint32_t offset;                    // chunk offset / file size info
    uint32_t data_len;                  // valid bytes in data field
    uint8_t  data[REMO2_FILE_DATA_MAX]; // path / data chunk / dir listing
} file_frame_t;

/* Compile-time check: file_frame_t must fit inside task_frame.text */
_Static_assert(sizeof(file_frame_t) <= REMO2_TEXT_LEN,
               "file_frame_t must fit inside task_frame.text");

#endif
