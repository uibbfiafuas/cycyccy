#ifndef REMO2_SESSION_H
#define REMO2_SESSION_H

int client_session_shell(const char *ip, int port, const char *passphrase);
int server_session_shell(int port, const char *passphrase);

#endif
