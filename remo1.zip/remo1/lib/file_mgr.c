#define _GNU_SOURCE
#include "file_mgr.h"

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/wait.h>

/* ============================================================
 * Dynamic poll array
 * ============================================================ */

void fm_pa_init(fm_poll_array_t *pa) { pa->count = 0; }

int fm_pa_add(fm_poll_array_t *pa, int fd, short events) {
    if (pa->count >= FM_MAX_POLL_FDS) return -1;
    pa->items[pa->count].fd     = fd;
    pa->items[pa->count].events = events;
    pa->items[pa->count].revents = 0;
    return pa->count++;
}

void fm_pa_remove(fm_poll_array_t *pa, int idx) {
    if (idx < 0 || idx >= pa->count) return;
    pa->items[idx] = pa->items[pa->count - 1];
    pa->count--;
}

int fm_pa_find(fm_poll_array_t *pa, int fd) {
    for (int i = 0; i < pa->count; i++)
        if (pa->items[i].fd == fd) return i;
    return -1;
}

/* ============================================================
 * Manager lifecycle
 * ============================================================ */

void fm_init(fm_ctx_t *ctx, int sock, const uint8_t *key,
             fm_send_fn send_fn, fm_poll_array_t *pa) {
    memset(ctx, 0, sizeof(*ctx));
    ctx->sock    = sock;
    ctx->key     = key;
    ctx->send_fn = send_fn;
    ctx->pa      = pa;
    for (int i = 0; i < REMO2_FILE_SLOTS; i++)
        ctx->slots[i].pipe_fd = -1;
}

void fm_cleanup(fm_ctx_t *ctx) {
    for (int i = 0; i < REMO2_FILE_SLOTS; i++)
        fm_free_slot(ctx, i);
}

/* ============================================================
 * Slot operations
 * ============================================================ */

int fm_allocate_slot(fm_ctx_t *ctx) {
    for (int i = 0; i < REMO2_FILE_SLOTS; i++) {
        if (!ctx->slots[i].active) {
            memset(&ctx->slots[i], 0, sizeof(ctx->slots[i]));
            ctx->slots[i].active   = 1;
            ctx->slots[i].pipe_fd  = -1;
            ctx->slots[i].poll_idx = -1;
            return i;
        }
    }
    return -1;
}

int fm_find_slot(fm_ctx_t *ctx, uint8_t rid) {
    for (int i = 0; i < REMO2_FILE_SLOTS; i++)
        if (ctx->slots[i].active && ctx->slots[i].request_id == rid)
            return i;
    return -1;
}

void fm_free_slot(fm_ctx_t *ctx, int idx) {
    if (idx < 0 || idx >= REMO2_FILE_SLOTS || !ctx->slots[idx].active) return;
    fm_slot_t *s = &ctx->slots[idx];

    if (s->pipe_fd >= 0 && ctx->pa) {
        int pi = fm_pa_find(ctx->pa, s->pipe_fd);
        if (pi >= 0) fm_pa_remove(ctx->pa, pi);
        close(s->pipe_fd);
    }

    if (s->child_pid > 0) {
        kill(s->child_pid, SIGTERM);
        int status;
        while (waitpid(s->child_pid, &status, WNOHANG) == 0) {
            usleep(10000);
            waitpid(s->child_pid, &status, WNOHANG);
        }
    }

    if (s->fp) { fclose(s->fp); s->fp = NULL; }
    memset(s, 0, sizeof(*s));
    s->pipe_fd  = -1;
    s->poll_idx = -1;
}

/* ============================================================
 * Frame builders
 * ============================================================ */

void fm_parse_frame(const task_frame_t *frame, file_frame_t *ff) {
    memcpy(ff, frame->text, sizeof(*ff));
}

void fm_build_cmd_frame(task_frame_t *frame, uint8_t op, uint8_t rid,
                         const char *data, size_t data_len) {
    memset(frame, 0, sizeof(*frame));
    frame->task_id = op;
    file_frame_t ff;
    memset(&ff, 0, sizeof(ff));
    ff.op         = op;
    ff.request_id = rid;
    if (data_len > REMO2_FILE_DATA_MAX) data_len = REMO2_FILE_DATA_MAX;
    ff.data_len = (uint32_t)data_len;
    if (data && data_len > 0) memcpy(ff.data, data, data_len);
    memcpy(frame->text, &ff, sizeof(ff));
}

void fm_build_data_frame(task_frame_t *frame, uint8_t rid,
                          uint32_t offset, const uint8_t *data, uint32_t len) {
    memset(frame, 0, sizeof(*frame));
    frame->task_id = REMO2_FILE_OP_DATA;
    file_frame_t ff;
    memset(&ff, 0, sizeof(ff));
    ff.op         = REMO2_FILE_OP_DATA;
    ff.request_id = rid;
    ff.offset     = offset;
    ff.data_len   = len;
    memcpy(ff.data, data, len);
    memcpy(frame->text, &ff, sizeof(ff));
}

void fm_build_status_frame(task_frame_t *frame, uint8_t status, uint8_t rid, uint32_t info) {
    memset(frame, 0, sizeof(*frame));
    frame->task_id = status;
    file_frame_t ff;
    memset(&ff, 0, sizeof(ff));
    ff.op         = status;
    ff.request_id = rid;
    ff.offset     = info;
    ff.data_len   = 0;
    memcpy(frame->text, &ff, sizeof(ff));
}

void fm_send_frame(fm_ctx_t *ctx, uint32_t *seq, const task_frame_t *frame) {
    task_frame_t f = *frame;
    f.seq = (*seq)++;
    ctx->send_fn(ctx->sock, ctx->key, REMO2_STREAM_FILE, &f);
}

/* ============================================================
 * Global request ID
 * ============================================================ */

static uint8_t g_rid = 0;
uint8_t fm_next_rid(void) { return ++g_rid; }

/* ============================================================
 * Client-side handlers
 * ============================================================ */

static void handle_list(fm_ctx_t *ctx, uint32_t *seq, const file_frame_t *ff) {
    const char *dirpath = (ff->data_len > 0) ? (const char *)ff->data : ".";
    DIR *d = opendir(dirpath);
    if (!d) {
        task_frame_t resp;
        fm_build_status_frame(&resp, REMO2_FILE_ERR_OPEN, ff->request_id, (uint32_t)errno);
        fm_send_frame(ctx, seq, &resp);
        fprintf(stderr, "[client] list failed: %s (errno=%d)\n", dirpath, errno);
        return;
    }

    task_frame_t resp;
    fm_build_status_frame(&resp, REMO2_FILE_OK, ff->request_id, 0);
    fm_send_frame(ctx, seq, &resp);

    char listing[REMO2_FILE_DATA_MAX];
    int off = 0;
    struct dirent *de;
    while ((de = readdir(d)) != NULL) {
        int room = (int)sizeof(listing) - off;
        if (room <= 2) {
            task_frame_t df;
            fm_build_data_frame(&df, ff->request_id, 0, (uint8_t *)listing, (uint32_t)off);
            fm_send_frame(ctx, seq, &df);
            off = 0;
            room = (int)sizeof(listing);
        }
        int n = snprintf(listing + off, room, "%s  ", de->d_name);
        if (n > 0) off += (n < room ? n : room - 1);
    }
    if (off > 0) {
        task_frame_t df;
        fm_build_data_frame(&df, ff->request_id, 0, (uint8_t *)listing, (uint32_t)off);
        fm_send_frame(ctx, seq, &df);
    }
    closedir(d);

    fm_build_status_frame(&resp, REMO2_FILE_OK, ff->request_id, 1);
    fm_send_frame(ctx, seq, &resp);
}

static void handle_delete(fm_ctx_t *ctx, uint32_t *seq, const file_frame_t *ff) {
    const char *filepath = (ff->data_len > 0) ? (const char *)ff->data : "";
    int rc = unlink(filepath);
    task_frame_t resp;
    fm_build_status_frame(&resp,
                          rc == 0 ? REMO2_FILE_OK : REMO2_FILE_ERR_IO,
                          ff->request_id, rc == 0 ? 0 : (uint32_t)errno);
    fm_send_frame(ctx, seq, &resp);
    fprintf(stderr, "[client] delete %s: %s\n", filepath, rc == 0 ? "ok" : "fail");
}

static void handle_download(fm_ctx_t *ctx, uint32_t *seq, const file_frame_t *ff) {
    const char *filepath = (ff->data_len > 0) ? (const char *)ff->data : "";
    int fd = open(filepath, O_RDONLY);
    if (fd < 0) {
        task_frame_t resp;
        fm_build_status_frame(&resp, REMO2_FILE_ERR_OPEN, ff->request_id, (uint32_t)errno);
        fm_send_frame(ctx, seq, &resp);
        return;
    }

    struct stat st;
    fstat(fd, &st);

    task_frame_t resp;
    fm_build_status_frame(&resp, REMO2_FILE_OK, ff->request_id, (uint32_t)st.st_size);
    fm_send_frame(ctx, seq, &resp);

    int si = fm_allocate_slot(ctx);
    if (si < 0) { close(fd); return; }
    ctx->slots[si].request_id = ff->request_id;
    ctx->slots[si].op         = REMO2_FILE_OP_DOWNLOAD;
    ctx->slots[si].pipe_fd    = fd;
    ctx->slots[si].offset     = 0;
    ctx->slots[si].total_size = (uint32_t)st.st_size;
}

static void handle_upload(fm_ctx_t *ctx, uint32_t *seq, const file_frame_t *ff) {
    const char *src  = (const char *)ff->data;
    size_t src_len   = strnlen(src, ff->data_len);
    const char *dst  = "";
    if (src_len + 1 < ff->data_len) dst = src + src_len + 1;

    const char *final_path = dst[0] ? dst : src;

    char target[REMO2_FILE_MAX_NAME + 128];
    snprintf(target, sizeof(target), "%s", final_path);
    {
        struct stat st2;
        if (dst[0] && stat(target, &st2) == 0 && S_ISDIR(st2.st_mode)) {
            const char *bn = strrchr(src, '/');
            bn = bn ? bn + 1 : src;
            snprintf(target + strlen(target), sizeof(target) - strlen(target), "/%s", bn);
        }
    }

    int fd = open(target, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) {
        task_frame_t resp;
        fm_build_status_frame(&resp, REMO2_FILE_ERR_OPEN, ff->request_id, (uint32_t)errno);
        fm_send_frame(ctx, seq, &resp);
        return;
    }

    task_frame_t resp;
    fm_build_status_frame(&resp, REMO2_FILE_OK, ff->request_id, 0);
    fm_send_frame(ctx, seq, &resp);

    int si = fm_allocate_slot(ctx);
    if (si < 0) { close(fd); return; }
    ctx->slots[si].request_id = ff->request_id;
    ctx->slots[si].op         = REMO2_FILE_OP_UPLOAD;
    ctx->slots[si].pipe_fd    = fd;
    ctx->slots[si].offset     = 0;
    strncpy(ctx->slots[si].path, target, sizeof(ctx->slots[si].path) - 1);
    fprintf(stderr, "[client] upload started: %s (slot=%d)\n", target, si);
}

/* ============================================================
 * Client-side dispatcher
 * ============================================================ */

void fm_client_dispatch(fm_ctx_t *ctx, uint32_t *seq, const task_frame_t *frame) {
    file_frame_t ff;
    fm_parse_frame(frame, &ff);

    // DATA frame
    if (ff.op == REMO2_FILE_OP_DATA && ff.request_id > 0) {
        int si = fm_find_slot(ctx, ff.request_id);
        if (si >= 0 && ctx->slots[si].op == REMO2_FILE_OP_UPLOAD && ctx->slots[si].pipe_fd >= 0) {
            (void)!pwrite(ctx->slots[si].pipe_fd, ff.data, ff.data_len, ff.offset);
            ctx->slots[si].offset += ff.data_len;
        }
        return;
    }

    // Status frame
    if (ff.op == REMO2_FILE_OK || ff.op == REMO2_FILE_ERR_OPEN || ff.op == REMO2_FILE_ERR_IO) {
        int si = fm_find_slot(ctx, ff.request_id);
        if (si >= 0 && ctx->slots[si].op == REMO2_FILE_OP_UPLOAD) {
            if (ff.op == REMO2_FILE_OK && ff.offset > 0) {
                fprintf(stderr, "[client] upload done: %s (%u bytes)\n",
                        ctx->slots[si].path, ff.offset);
                fm_free_slot(ctx, si);
            } else if (ff.op != REMO2_FILE_OK) {
                fm_free_slot(ctx, si);
            }
        }
        return;
    }

    // Command frame
    switch (ff.op) {
    case REMO2_FILE_OP_LIST:     handle_list(ctx, seq, &ff);     break;
    case REMO2_FILE_OP_DOWNLOAD: handle_download(ctx, seq, &ff); break;
    case REMO2_FILE_OP_UPLOAD:   handle_upload(ctx, seq, &ff);   break;
    case REMO2_FILE_OP_DELETE:   handle_delete(ctx, seq, &ff);   break;
    default: break;
    }
}

/* ============================================================
 * Client-side: flush download slots
 * ============================================================ */

void fm_client_flush_downloads(fm_ctx_t *ctx, uint32_t *seq) {
    for (int si = 0; si < REMO2_FILE_SLOTS; si++) {
        fm_slot_t *s = &ctx->slots[si];
        if (!s->active || s->op != REMO2_FILE_OP_DOWNLOAD || s->pipe_fd < 0) continue;

        uint8_t buf[REMO2_FILE_DATA_MAX];
        ssize_t n = read(s->pipe_fd, buf, sizeof(buf));
        if (n > 0) {
            task_frame_t df;
            fm_build_data_frame(&df, s->request_id, s->offset, buf, (uint32_t)n);
            fm_send_frame(ctx, seq, &df);
            s->offset += (uint32_t)n;
        } else if (n == 0) {
            task_frame_t done;
            fm_build_status_frame(&done, REMO2_FILE_OK, s->request_id, s->offset);
            fm_send_frame(ctx, seq, &done);
            fprintf(stderr, "[client] download done: %u bytes\n", s->offset);
            fm_free_slot(ctx, si);
        } else {
            if (errno == EAGAIN || errno == EWOULDBLOCK) continue;
            task_frame_t errf;
            fm_build_status_frame(&errf, REMO2_FILE_ERR_IO, s->request_id, (uint32_t)errno);
            fm_send_frame(ctx, seq, &errf);
            fm_free_slot(ctx, si);
        }
    }
}

/* ============================================================
 * Server-side: prepare command and send
 * ============================================================ */

int fm_server_prepare_cmd(fm_ctx_t *ctx, uint32_t *seq,
                           uint8_t op, const char *psrc, const char *pdst) {
    uint8_t rid = fm_next_rid();
    int si = fm_allocate_slot(ctx);
    if (si < 0) return -1;

    ctx->slots[si].request_id = rid;
    ctx->slots[si].op         = op;

    if (op == REMO2_FILE_OP_DOWNLOAD) {
        char local[REMO2_FILE_MAX_NAME + 128];
        if (pdst && pdst[0]) {
            snprintf(local, sizeof(local), "%s", pdst);
        } else {
            const char *bn = strrchr(psrc, '/');
            bn = bn ? bn + 1 : psrc;
            snprintf(local, sizeof(local),
                     "/home/newym/Desktop/remo1/server/downloaded_%s", bn);
        }
        {
            struct stat st_dst;
            if (stat(local, &st_dst) == 0 && S_ISDIR(st_dst.st_mode)) {
                const char *bn = strrchr(psrc, '/');
                bn = bn ? bn + 1 : psrc;
                snprintf(local + strlen(local), sizeof(local) - strlen(local), "/%s", bn);
            }
        }
        ctx->slots[si].fp = fopen(local, "wb");
        if (!ctx->slots[si].fp) {
            fprintf(stderr, "[server] cannot create: %s\n", local);
            fm_free_slot(ctx, si); return -1;
        }
        printf("[server] downloading %s -> %s\n", psrc, local);
        strncpy(ctx->slots[si].path, local, sizeof(ctx->slots[si].path) - 1);
    }
    else if (op == REMO2_FILE_OP_UPLOAD) {
        const char *local  = psrc;
        const char *remote = (pdst && pdst[0]) ? pdst : local;
        ctx->slots[si].fp = fopen(local, "rb");
        if (!ctx->slots[si].fp) {
            fprintf(stderr, "[server] cannot open: %s\n", local);
            fm_free_slot(ctx, si); return -1;
        }
        fseek(ctx->slots[si].fp, 0, SEEK_END);
        long sz = ftell(ctx->slots[si].fp);
        fseek(ctx->slots[si].fp, 0, SEEK_SET);
        printf("[server] uploading %s -> %s (%ld bytes)\n", local, remote, sz);
        strncpy(ctx->slots[si].path, remote, sizeof(ctx->slots[si].path) - 1);
        ctx->slots[si].total_size = (uint32_t)sz;
    }
    else if (op == REMO2_FILE_OP_LIST) {
        printf("[server] listing: %s\n", psrc[0] ? psrc : ".");
    }
    else if (op == REMO2_FILE_OP_DELETE) {
        printf("[server] deleting: %s\n", psrc);
    }

    // Build path buffer: src\0dst
    char path_buf[REMO2_FILE_MAX_NAME];
    size_t send_len = strlen(psrc) + 1;
    memcpy(path_buf, psrc, send_len);
    if (pdst && pdst[0]) {
        size_t dlen = strlen(pdst) + 1;
        memcpy(path_buf + send_len, pdst, dlen);
        send_len += dlen;
    }

    task_frame_t cmd;
    fm_build_cmd_frame(&cmd, op, rid, path_buf, send_len);
    cmd.seq = (*seq)++;
    ctx->send_fn(ctx->sock, ctx->key, REMO2_STREAM_FILE, &cmd);
    return 0;
}

/* ============================================================
 * Server-side: flush upload slots
 * ============================================================ */

void fm_server_flush_uploads(fm_ctx_t *ctx, uint32_t *seq) {
    for (int si = 0; si < REMO2_FILE_SLOTS; si++) {
        fm_slot_t *s = &ctx->slots[si];
        if (!s->active || s->op != REMO2_FILE_OP_UPLOAD || !s->fp) continue;

        uint8_t buf[REMO2_FILE_DATA_MAX];
        size_t nr = fread(buf, 1, sizeof(buf), s->fp);
        if (nr > 0) {
            task_frame_t df;
            fm_build_data_frame(&df, s->request_id, s->offset, buf, (uint32_t)nr);
            fm_send_frame(ctx, seq, &df);
            s->offset += (uint32_t)nr;
        } else {
            task_frame_t done;
            fm_build_status_frame(&done, REMO2_FILE_OK, s->request_id, s->offset);
            fm_send_frame(ctx, seq, &done);
            printf("[server] upload done: %s (%u bytes)\n", s->path, s->offset);
            fm_free_slot(ctx, si);
        }
    }
}

/* ============================================================
 * Server-side: dispatch incoming FILE stream frames
 * ============================================================ */

void fm_server_dispatch(fm_ctx_t *ctx, const task_frame_t *frame) {
    file_frame_t ff;
    fm_parse_frame(frame, &ff);

    // DATA frame
    if (ff.op == REMO2_FILE_OP_DATA) {
        int si = fm_find_slot(ctx, ff.request_id);
        if (si >= 0 && ctx->slots[si].op == REMO2_FILE_OP_DOWNLOAD && ctx->slots[si].fp) {
            fseek(ctx->slots[si].fp, (long)ff.offset, SEEK_SET);
            fwrite(ff.data, 1, ff.data_len, ctx->slots[si].fp);
            ctx->slots[si].offset += ff.data_len;
            fflush(ctx->slots[si].fp);
        }
        if (si >= 0 && ctx->slots[si].op == REMO2_FILE_OP_LIST) {
            fwrite(ff.data, 1, ff.data_len, stdout);
            fflush(stdout);
        }
        return;
    }

    // Status frame
    if (ff.op == REMO2_FILE_OK || ff.op == REMO2_FILE_ERR_OPEN || ff.op == REMO2_FILE_ERR_IO) {
        int si = fm_find_slot(ctx, ff.request_id);
        if (si >= 0 && ctx->slots[si].op == REMO2_FILE_OP_DOWNLOAD && ff.op == REMO2_FILE_OK) {
            if (ff.offset > 0 && ctx->slots[si].total_size == 0)
                ctx->slots[si].total_size = ff.offset;
            if (ff.offset > 0 && ctx->slots[si].total_size > 0 &&
                ctx->slots[si].offset >= ctx->slots[si].total_size) {
                printf("[server] download done: %s (%u bytes)\n",
                       ctx->slots[si].path, ctx->slots[si].offset);
                fm_free_slot(ctx, si);
            }
        } else if (si >= 0 && ctx->slots[si].op == REMO2_FILE_OP_UPLOAD) {
            if (ff.op == REMO2_FILE_OK && ff.offset > 0) {
                printf("[server] upload done: %s (%u bytes)\n",
                       ctx->slots[si].path, ff.offset);
                fm_free_slot(ctx, si);
            }
        } else if (si >= 0 && ctx->slots[si].op == REMO2_FILE_OP_DELETE) {
            printf("[server] delete: %s\n", ff.op == REMO2_FILE_OK ? "ok" : "fail");
            fm_free_slot(ctx, si);
        } else if (si >= 0 && ctx->slots[si].op == REMO2_FILE_OP_LIST) {
            if (ff.offset == 1) {
                printf("\n");
                fflush(stdout);
                fm_free_slot(ctx, si);
            }
        } else {
            if (ff.op != REMO2_FILE_OK)
                printf("[server] op failed: status=%u errno=%u\n", ff.op, ff.offset);
            if (si >= 0) fm_free_slot(ctx, si);
        }
    }
}
